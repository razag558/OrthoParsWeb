﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Web.UI;
using WCharts;
using System.Globalization;
using System.Configuration;
using System.Text;
using System.Net.Mail;





namespace rstemenu
{

    public class Methods
    {

        public string connStr = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

        public string atr = "@";

        public string userNameforAuthentication(string un, string pwd)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {

                if (un == "arsun" && pwd == "zio@$")
                    return connStr.ToString();
                else
                    return "";
            }
            catch (Exception ex)
            {
                return "Er";
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }

            return connStr.ToString();
        }



        public void Registeruser(string first, string last, string country_name, string user_name, string city, string email, string password, string phone)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_patient_registeration", con);
                cmd.Parameters.Add(new SqlParameter("@firstname", first));
                cmd.Parameters.Add(new SqlParameter("@lastname", last));
                cmd.Parameters.Add(new SqlParameter("@country", country_name));
                cmd.Parameters.Add(new SqlParameter("@city", city));
                cmd.Parameters.Add(new SqlParameter("@email", email));
                cmd.Parameters.Add(new SqlParameter("@username", user_name));
                cmd.Parameters.Add(new SqlParameter("@userpassword", password));
                cmd.Parameters.Add(new SqlParameter("@phone_number", phone));

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                // SP_patient_registeration ............ procedure
                // patient_register .......  table

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
        }


        public void submitting_record(string preorposttreatment, float cvalue, float fvalue, float ivalue, float lvalue, float nvalue, string username, DateTime pars_datetime, string patient_id)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {

                cmd = new SqlCommand("SP_Patient_ParsRecord", con);
                cmd.Parameters.Add(new SqlParameter("@preorposttreatment", preorposttreatment));
                cmd.Parameters.Add(new SqlParameter("@cvalue", cvalue));
                cmd.Parameters.Add(new SqlParameter("@fvalue", fvalue));
                cmd.Parameters.Add(new SqlParameter("@ivalue", ivalue));
                cmd.Parameters.Add(new SqlParameter("@lvalue", lvalue));
                cmd.Parameters.Add(new SqlParameter("@nvalue", nvalue));
                cmd.Parameters.Add(new SqlParameter("@username", username));
                cmd.Parameters.Add(new SqlParameter("@pars_datetime", pars_datetime));
                cmd.Parameters.Add(new SqlParameter("@patient_id", patient_id));

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }

        }



        public DataTable Fetching_all_data()
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_patient_record_fetching", con);
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }




        public DataTable Fetching_data_for_updating(int id)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();

            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_patient_fetching_for_id", con);
                cmd.Parameters.Add(new SqlParameter("@id", id));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public void Updating_record(int id, string first, string last, string country_name, string user_name, string city, string email, string password, string phone)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_Record_ofuser_Updating", con);
                cmd.Parameters.Add(new SqlParameter("@id", id));
                cmd.Parameters.Add(new SqlParameter("@firstname", first));
                cmd.Parameters.Add(new SqlParameter("@lastname", last));
                cmd.Parameters.Add(new SqlParameter("@country", country_name));
                cmd.Parameters.Add(new SqlParameter("@city", city));
                cmd.Parameters.Add(new SqlParameter("@email", email));
                cmd.Parameters.Add(new SqlParameter("@username", user_name));
                cmd.Parameters.Add(new SqlParameter("@userpassword", password));
                cmd.Parameters.Add(new SqlParameter("@phone_number", phone));

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }



        }

        public void deleteUserByID(string id)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_Record_ofuser_Deleting", con);
                cmd.Parameters.Add(new SqlParameter("@id", id));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }


        }


        public DataTable CheckNewUserEmail(string emailaddress)
        {

            SqlConnection con = new SqlConnection(connStr);
            con.Open();

            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_user_email_validation", con);
                cmd.Parameters.Add(new SqlParameter("@email", emailaddress));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }



        public DataTable GetUserValidUser(string UserName)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();

            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_user_username_validation", con);
                cmd.Parameters.Add(new SqlParameter("@username", UserName));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;


        }




        public DataTable FetchingDataofspecificUser(string username)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();

            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_patient_Values_fetching", con);
                cmd.Parameters.Add(new SqlParameter("@username", username));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }



        public int submittion_of_Patient_info(string doc_name, string pat_id, string pat_name, string gender, string impact_teeth, string missing_teeth, string extracted, string replacement, string restorative, string date, string username)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            int patientid = 0;
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_patient_info_submition", con);
                cmd.Parameters.Add(new SqlParameter("@doc_name", doc_name));
                cmd.Parameters.Add(new SqlParameter("@pat_id", pat_id));
                cmd.Parameters.Add(new SqlParameter("@pat_name", pat_name));
                cmd.Parameters.Add(new SqlParameter("@pat_gender", gender));
                cmd.Parameters.Add(new SqlParameter("@impact_teeth", impact_teeth));
                cmd.Parameters.Add(new SqlParameter("@missing_teeth", missing_teeth));
                cmd.Parameters.Add(new SqlParameter("@extracted", extracted));
                cmd.Parameters.Add(new SqlParameter("@replacement", replacement));
                cmd.Parameters.Add(new SqlParameter("@restorative", restorative));
                cmd.Parameters.Add(new SqlParameter("@entry_date", date));
                cmd.Parameters.Add(new SqlParameter("@username", username));
                cmd.Parameters.Add("@return_id", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                patientid = Convert.ToInt32(cmd.Parameters["@return_id"].Value);
                return patientid;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return patientid;
        }

        public DataTable fetching_patient_info(string doc_username)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {

                cmd = new SqlCommand("SP_fetching_patient_info", con);
                cmd.Parameters.Add(new SqlParameter("@doc_username", doc_username));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public void detetingrecordbyid(string id)
        {


            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {

                cmd = new SqlCommand("SP_deleting_record_row", con);
                cmd.Parameters.Add(new SqlParameter("@record_id", id));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);

            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }


        }


        public DataTable fetching_patient_info_for_update(int id)
        {

            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {

                cmd = new SqlCommand("SP_fetching_patient_info_by_id", con);
                cmd.Parameters.Add(new SqlParameter("@id", id));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;

        }


        public void submittion_of_Patient_info_update(int id, string doc_name, string pat_id, string pat_name, string gender, string impact_teeth, string missing_teeth, string extracted, string replacement, string restorative, string date, string username)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();

            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_patient_info_update", con);
                cmd.Parameters.Add(new SqlParameter("@id", id));
                cmd.Parameters.Add(new SqlParameter("@doc_name", doc_name));
                cmd.Parameters.Add(new SqlParameter("@pat_id", pat_id));
                cmd.Parameters.Add(new SqlParameter("@pat_name", pat_name));
                cmd.Parameters.Add(new SqlParameter("@pat_gender", gender));
                cmd.Parameters.Add(new SqlParameter("@impact_teeth", impact_teeth));
                cmd.Parameters.Add(new SqlParameter("@missing_teeth", missing_teeth));
                cmd.Parameters.Add(new SqlParameter("@extracted", extracted));
                cmd.Parameters.Add(new SqlParameter("@replacement", replacement));
                cmd.Parameters.Add(new SqlParameter("@restorative", restorative));
                cmd.Parameters.Add(new SqlParameter("@entry_date", date));
                cmd.Parameters.Add(new SqlParameter("@username", username));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }

        }

        public void Pars_Result_submit(int prevalue, int postvalue, int point_value, double percentage, int pat_id)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_Pars_Results_submittion", con);
                cmd.Parameters.Add(new SqlParameter("@pre_value", prevalue));
                cmd.Parameters.Add(new SqlParameter("@post_value", postvalue));
                cmd.Parameters.Add(new SqlParameter("@point_value", point_value));
                cmd.Parameters.Add(new SqlParameter("@per_value", percentage));
                cmd.Parameters.Add(new SqlParameter("@pat_id", pat_id));

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
        }


        public DataTable fetching_Pars_values_by_id(int  id)
        {

            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {

                cmd = new SqlCommand("SP_fetching_Pars_Results", con);
                cmd.Parameters.Add(new SqlParameter("@id", id));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;

        }

        public DataTable GetPatinetData(int id)
        {

            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {

                cmd = new SqlCommand("SP_GetPatientInfo", con);
                cmd.Parameters.Add(new SqlParameter("@id", id));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;

        }




        public string SendEmail(string emailto,string pre_value, string post_value , int point_value, double percentage)
        {
            try
            {
                 string bodycontent = "<b>Dear M/S</b> <br> Here your Accessment :<br><p> Pretreatment Value =" + pre_value + "<br>  Posttreatment value = " +post_value + " <br> Point Value = " +point_value+ " <br> Percentage Value = " + percentage ;

                MailMessage message = new MailMessage();
                message.To.Add(new MailAddress(emailto));
                message.From = new MailAddress("EasyPars@gmail.com");
                
                message.Subject = "Pars Result Report";
              
                message.Body = bodycontent;
                SmtpClient client = new SmtpClient();

                client.UseDefaultCredentials = false;
                client.EnableSsl = true;
                message.IsBodyHtml = true;
                client.Timeout = 10000;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.Send(message);
                message.To.Clear();

                return "";
                 
            }

            catch (Exception ex)
            {
                return Convert.ToString(ex);
                
            }

           

        }

        public DataTable fetching_complete_Parsvalues_pre(int patient_id)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_fetching_complete_patient_value_pre", con);
                cmd.Parameters.Add(new SqlParameter("@patient_id", patient_id));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }

        public DataTable fetching_complete_Parsvalues(int patient_id)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_fetching_complete_patient_value", con);
                cmd.Parameters.Add(new SqlParameter("@patient_id", patient_id));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;


        }

        public void Updating_Patient_values_results(string crowding, string buccal, string overjet, string overbite, string midline, string crowding2, string buccal2, string overjet2, string overbite2, string midline2, int id, string p1, string p2, string percentage, string point, string username_active)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();

            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_Updating_Result_Values", con);
                cmd.Parameters.Add(new SqlParameter("@patient_id", id));
                cmd.Parameters.Add(new SqlParameter("@precrowding", crowding));
                cmd.Parameters.Add(new SqlParameter("@prebuccal", buccal));
                cmd.Parameters.Add(new SqlParameter("@preoverjet", overjet));
                cmd.Parameters.Add(new SqlParameter("@preoverbite", overbite));
                cmd.Parameters.Add(new SqlParameter("@premidline", midline));
                cmd.Parameters.Add(new SqlParameter("@poscrowding", crowding2));
                cmd.Parameters.Add(new SqlParameter("@posbuccal", buccal2));
                cmd.Parameters.Add(new SqlParameter("@posoverjet", overjet2));
                cmd.Parameters.Add(new SqlParameter("@posoverbite", overbite2));
                cmd.Parameters.Add(new SqlParameter("@posmidline", midline2));
                cmd.Parameters.Add(new SqlParameter("@prevalue", p1));
                cmd.Parameters.Add(new SqlParameter("@postvalue", p2));
                cmd.Parameters.Add(new SqlParameter("@percentage", percentage));
                cmd.Parameters.Add(new SqlParameter("@point", point));
                cmd.Parameters.Add(new SqlParameter("@username", username_active));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);


            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
        }

        public string getting_userpassword(string user_name,string email)
        {
            SqlConnection con = new SqlConnection(connStr);
            con.Open();
            string password = "";
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_forgetPassword", con);
                cmd.Parameters.Add(new SqlParameter("@user_name", user_name));
                cmd.Parameters.Add(new SqlParameter("@email", email));
            
                cmd.Parameters.Add("@password", SqlDbType.NVarChar,250).Direction = ParameterDirection.Output;
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                password = Convert.ToString(cmd.Parameters["@password"].Value);
                return password;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return password;
        }


    }
}