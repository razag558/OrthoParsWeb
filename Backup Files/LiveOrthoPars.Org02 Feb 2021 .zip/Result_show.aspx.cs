﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace rstemenu
{
    public partial class Result_show : System.Web.UI.Page
    {
        string pre_value,post_value;

        

        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/helppage.aspx?id=54&heading=percentage");
        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/helppage.aspx?id=53&heading=point");
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            Session["Posttreatment_value"] = "0";
            Session["Pretreatment_value"] = "0";

            if (Request.QueryString["pre"]!= null)
            {
                pre_value = Request.QueryString["pre"];
            }

            if (Request.QueryString["post"] != null)
            {
                post_value = Request.QueryString["post"];
            }
            int result_value = Convert.ToInt32(pre_value) - Convert.ToInt32(post_value);
            pretreatment_value.Text ="Pretreatment Value of PAR : "+ pre_value;
            Label1.Text = " Posttreatment Value of PAR: " +  post_value;
            Label2.Text = " Point Result of PAR : "+ Convert.ToString(result_value);

            if(result_value >22)
            {
                point_result.Text = "( Point based treatment changes: P1-P2. Change is more than 22 point indicates a great improvement secondary to the treatment.)";
            }
            if(result_value < 22)
            {
                point_result.Text = "( Point based treatment changes: P1-P2. Change is less than 22 point indicates no improvement) ";
            }
            double percentage = Math.Round((   ( Convert.ToDouble(pre_value) - Convert.ToDouble(post_value) )* 100) / Convert.ToDouble(pre_value),2 );
            
            Label3.Text = " Percentage Result of PAR : " +   percentage +"%" ; 

            if(percentage>30  && percentage <70)
            {
                Label4.Text = " (PAR Percentage result is in between 30% and 70% which indicates improvement   )";
            }
            else if(percentage <30)
            {
                Label4.Text = " (PAR Percentage result is lesser than 30%   which indicates there is no improvement )";
            }
            else if (percentage > 70)
            {
                Label4.Text = " (PAR Percentage result is greater than 70% which indicates Great improvement)";
            }


        }
    }
}