﻿using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TradingHub
{
    public partial class Trademe_Response : System.Web.UI.Page
    {
        Methods.Data obj = new Methods.Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            BindResponse();
        }



        public void BindResponse()
        {
            string seller_ID = Session["SellerID"].ToString();
            string channel_ID = "111";
            DataTable dt = obj.Fetching_Trademe_Response(seller_ID, channel_ID);

            datatable.DataSource = dt;
            datatable.DataBind();


        }

        public void Advance_search_Click(Object sender,EventArgs e)
        {
            advance_search_panel.Visible = true;
        }
       

        protected void csv_download_Click(object sender, EventArgs e)
        {
            string sellerID = Session["SellerID"].ToString();
            DataTable dt = obj.FetchProducts(Convert.ToInt32(sellerID));

            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=ProductLIst (" + sellerID + ").csv");
            Response.Charset = "";
            Response.ContentType = "application/text";
            Response.ContentEncoding = System.Text.Encoding.GetEncoding(1252);

            StringBuilder columnbind = new StringBuilder();

            columnbind.Append("," + "," + "Manage " + "," + " Feedback ,");


            columnbind.Append("\r\n");

            columnbind.Append("ID");
            columnbind.Append(",");

            columnbind.Append("Aution ID");
            columnbind.Append(",");

            columnbind.Append("Promo Group");
            columnbind.Append(",");

            columnbind.Append("User Name");
            columnbind.Append(",");

            columnbind.Append("Action");
            columnbind.Append(",");


            columnbind.Append("Reciprocated");
            columnbind.Append(",");

            columnbind.Append("Date");
            columnbind.Append(",");

            columnbind.Append("Product");
            columnbind.Append(",");

            columnbind.Append("Listing ID");
            columnbind.Append(",");

            columnbind.Append("Feedback ID");
            columnbind.Append(",");

            columnbind.Append("Purchase ID");
            columnbind.Append(",");

            columnbind.Append("Channel ID");
            columnbind.Append(",");


           

            foreach (GridViewRow datatable in datatable.Rows)
            {
                
                Label lbl_feedbackid = (Label)datatable.Cells[0].FindControl("lbl_feedbackid");
                Label lbl_autionid = (Label)datatable.Cells[1].FindControl("lbl_autionid");
                Label Ibl_promo_group = (Label)datatable.Cells[2].FindControl("Ibl_promo_group");
                Label lbl_username = (Label)datatable.Cells[3].FindControl("lbl_username");
                Label lbl_action = (Label)datatable.Cells[4].FindControl("lbl_action");
                Label lbl_reciprocated = (Label)datatable.Cells[5].FindControl("lbl_reciprocated");
                Label lbl_date = (Label)datatable.Cells[6].FindControl("lbl_date");
                Label lbl_product = (Label)datatable.Cells[7].FindControl("lbl_product");
                Label lbl_listingid = (Label)datatable.Cells[8].FindControl("lbl_listingid");
                Label lbl_feedback = (Label)datatable.Cells[9].FindControl("lbl_feedback");
                Label lbl_purchaseid = (Label)datatable.Cells[10].FindControl("lbl_purchaseid");
                Label lbl_channel_id = (Label)datatable.Cells[11].FindControl("lbl_channel_id");
            
                    columnbind.Append("\r\n");
                    columnbind.Append(lbl_feedbackid.Text.ToString() + ",");
                    columnbind.Append(lbl_autionid.Text.ToString() + ",");
                    columnbind.Append(Ibl_promo_group.Text.ToString() + ",");
                    columnbind.Append(lbl_username.Text.ToString() + ",");
                    columnbind.Append(lbl_action.Text.ToString() + ",");
                    columnbind.Append(lbl_reciprocated.Text.ToString() + ",");
                    columnbind.Append(lbl_date.Text.ToString() + ",");
                    columnbind.Append(lbl_product.Text.ToString() + ",");
                    columnbind.Append(lbl_listingid.Text.ToString() + ",");
                    columnbind.Append(lbl_feedback.Text.ToString() + ",");
                    columnbind.Append(lbl_purchaseid.Text.ToString() + ",");
                    columnbind.Append(lbl_channel_id.Text.ToString() + ",");
              
                
            }
            Response.Output.Write(columnbind.ToString());
            Response.Flush();
            Response.End();



        }

        protected void pdf_download_Click(object sender, EventArgs e)
        {

            string sellerID = Session["SellerID"].ToString();
            DataTable dt = obj.FetchProducts(Convert.ToInt32(sellerID));

            StringBuilder columnbind = new StringBuilder();
            columnbind.Append("<div>");
            columnbind.Append("<h3>Product List</h3>  ");
            columnbind.Append("</div>");

            columnbind.Append("<table width='100%' border='1' >");
            if (dt.Rows.Count > 0)
            {
                string status_product = "";
                columnbind.Append("<tr><td> ID </td><td> Aution ID</td><td>Promo Group</td><td>Username</td><td>Action</td><td>Reciprocated</td><td>Date</td><td>Product</td><td>ListingID</td><td>FeedBackID</td><td>Purchase ID</td><td>Channel ID</td></tr>  ");

                foreach (GridViewRow datatable in datatable.Rows)
                {
                    Label lbl_feedbackid = (Label)datatable.Cells[0].FindControl("lbl_feedbackid");
                    Label lbl_autionid = (Label)datatable.Cells[1].FindControl("lbl_autionid");
                    Label Ibl_promo_group = (Label)datatable.Cells[2].FindControl("Ibl_promo_group");
                    Label lbl_username = (Label)datatable.Cells[3].FindControl("lbl_username");
                    Label lbl_action = (Label)datatable.Cells[4].FindControl("lbl_action");
                    Label lbl_reciprocated = (Label)datatable.Cells[5].FindControl("lbl_reciprocated");
                    Label lbl_date = (Label)datatable.Cells[6].FindControl("lbl_date");
                    Label lbl_product = (Label)datatable.Cells[7].FindControl("lbl_product");
                    Label lbl_listingid = (Label)datatable.Cells[8].FindControl("lbl_listingid");
                    Label lbl_feedback = (Label)datatable.Cells[9].FindControl("lbl_feedback");
                    Label lbl_purchaseid = (Label)datatable.Cells[10].FindControl("lbl_purchaseid");
                    Label lbl_channel_id = (Label)datatable.Cells[11].FindControl("lbl_channel_id");



                    columnbind.Append("<tr><td>" +
                            lbl_feedbackid.Text.ToString() + "</td><td>" + lbl_autionid.Text.ToString() + "</td><td>" + Ibl_promo_group.Text.ToString() + "</td><td>" + lbl_username.Text.ToString() + "</td><td>" + lbl_action.Text.ToString() + "</td><td>" + lbl_reciprocated.Text.ToString() + "</td><td>" + lbl_date.Text.ToString() + "</td><td>" + lbl_product.Text.ToString() +"</td><td>" + lbl_listingid.Text.ToString() + "</td><td>" + lbl_feedback.Text.ToString() + "</td><td>" + lbl_purchaseid.Text.ToString()+ "</td><td>" + lbl_channel_id.Text.ToString() + "</td></tr>");
                 

                }


            }
            columnbind.Append("</table>");

            StringReader sr = new StringReader(columnbind.ToString());

            Document pdfDoc = new Document(PageSize.LEGAL_LANDSCAPE, 10f, 10f, 10f, 0f);
            HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
            byte[] bytes;
            using (MemoryStream memoryStream = new MemoryStream())
            {
                PdfWriter writer = PdfWriter.GetInstance(pdfDoc, memoryStream);
                pdfDoc.Open();

                htmlparser.Parse(sr);
                pdfDoc.Close();

                bytes = memoryStream.ToArray();
                memoryStream.Close();
            }





            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=allProducts (" + sellerID + ") .pdf");
            Response.Charset = "";
            Response.ContentType = "application/text";
            Response.ContentEncoding = System.Text.Encoding.GetEncoding(1252);
            Response.Buffer = true;
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.BinaryWrite(bytes);
            Response.End();
            Response.Close();
        }


        public void Advance_Result_Click(object sender,EventArgs e)
        {
            string find = "";
            string where = "";
            string startwith = "";
            string todate = "";
            string fromdate = "";
            string promogroup = "";
            string action = "";
          
            find = dropdown_find.SelectedItem.Value.Trim().ToString();
            where = dropdown_where.SelectedItem.Value.Trim().ToString();
            startwith = textbox_startwith.Text.Trim().ToString();
            todate = txt_todate.Text.Trim().ToString();
            fromdate = txt_fromdate.Text.Trim().ToString();
            action = ddl_action.SelectedItem.Value.Trim().ToString();
            promogroup = ddl_promogroup.SelectedItem.Value.Trim().ToString();
            string sellerID = Session["SellerID"].ToString();
            DataTable searched_table = obj.fetching_advance_search_of_feedback(find, where, startwith,todate, fromdate,promogroup,action,sellerID);

            datatable.DataSource = searched_table;
            datatable.DataBind();
        }

        protected void datatable_PreRender(object sender, EventArgs e)
        {
            if (datatable.Rows.Count > 0)
            {
                datatable.UseAccessibleHeader = true;
                datatable.HeaderRow.TableSection = TableRowSection.TableHeader;
            }
        }
        protected void OnPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            datatable.PageIndex = e.NewPageIndex;
            BindResponse();
        }

        protected void datatable_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            string Response_id;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Response_id = DataBinder.Eval(e.Row.DataItem, "ID").ToString();

            }
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                LinkButton l = (LinkButton)e.Row.FindControl("btn_Delete");

                if (l != null && l.CommandName == "Delete")

                    l.OnClientClick = "return confirm('Are you sure want to delete this record?');";

            }
        }

        protected void datatable_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (((LinkButton)e.CommandSource).CommandName)
                {
                    case "Delete":
                        obj.deleteResponseByID((e.CommandArgument).ToString());
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('General Product Deleted Successfully');", true);
                        break;
                }
            }
            catch (Exception ex)
            {
                
            }
        }

        protected void datatable_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

            BindResponse();
        }


        protected void Reset_OnClick_Click(object sender,EventArgs e)
        {
            txt_fromdate.Text = "";
            txt_todate.Text = "";
            ddl_action.SelectedIndex = 0;
            ddl_promogroup.SelectedIndex = 0;
            dropdown_find.SelectedIndex = 0;
            dropdown_where.SelectedIndex = 0;
            textbox_startwith.Text = "";
        }
    }
}