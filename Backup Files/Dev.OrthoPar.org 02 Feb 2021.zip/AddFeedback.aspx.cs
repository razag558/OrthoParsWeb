﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TradingHub
{
    public partial class AddFeedback : System.Web.UI.Page
    {
        Methods.Data obj = new Methods.Data();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Save_Feedback_Click(object sender,EventArgs e)
        {
            string autionid = txt_autionID.Text.ToString();
            string date = txt_feedback_date.Text.ToString();
            string message = txt_feedback_message.Text.ToString();
            string sellerID = Session["SellerID"].ToString();
            string channleID = "111";
            string feedbackuserid = "234";

            obj.Inserting_Feedback_Custom(autionid,date,message,sellerID,channleID,feedbackuserid);






        }
    }
}