﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Configuration;
using System.Net;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Text;

namespace TradingHub.Methods
{
    public class Data
    {
        public string connectionStr = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;

        ////////////////////////////////////////// Add Product ///////////////////////////////////////////////////////////////////

        public int AddProduct(string p_category, string p_categoryPAth, string p_title, string p_subTitle, string p_partnumber, string p_shortdescription,

                               string p_DetailDescription, string p_InvoiceDescription, string p_SaleStartDate, string p_SaleEndDate, bool p_Status,

                               string p_BrandName, string p_Condition, float p_MaxOrderQuantity, string p_upc, string p_upc2,

                               float p_cost, float p_gst, string p_taxtype, float P_InclusiveTax, float P_ExclusiveTax, float P_Markup,

                               float P_SalePrice, float P_Quantity, DateTime P_RestockSDate, string P_StockAvailability, float P_SafetyStockLevel,

                               float P_ReorderStockLevel, float P_Weight, float P_Length, float P_Width, float P_Height, float P_Volume, float P_Wattage,

                               string P_WeightUnit, string P_LengthUnit, string P_WidthUnit, string P_HeightUnit, string P_VolumeUnit, string P_WattageUnit,

                               int P_NumberofPieces, string P_Shape, string P_IncludedComponents, int P_PackageQty, float P_SPackageLength, float P_SPackageWidth,

                               float P_SPackageHeight, string P_SPackageUnit, float P_SDepth, string P_SDepthUnit, string P_Size, string P_ShippingRateOption,

                               string P_ShippingPickupOption, int P_ShipptingTemplateID, float P_SHandlingTime, string P_WareHouselocationID, string P_VendorCategory,

                               string P_VendorName, string P_VendorItemCode, float P_VenderPrice, string P_VendorCurrency, string P_VenderLinkURL, string P_PublicNotes,

                               string P_PrivateNotes, string P_Createdby, DateTime P_CreatedDatetime, string P_ModifiedBy, DateTime P_ModifiedDatetime,

                               string P_Meta_KeyWords, string P_Meta_Description, int sellerID, string tmTitle, string tmSubtitle, string tmShortDescription,
                                string tmDetailDescription, int channelID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_AddProduct", connection);


                cmd.Parameters.Add(new SqlParameter("@P_Category", p_category));
                cmd.Parameters.Add(new SqlParameter("@P_CategoryPath", p_categoryPAth));
                cmd.Parameters.Add(new SqlParameter("@P_Title", p_title));
                cmd.Parameters.Add(new SqlParameter("@P_SubTitle", p_subTitle));
                cmd.Parameters.Add(new SqlParameter("@P_PartNumber", p_partnumber));
                cmd.Parameters.Add(new SqlParameter("@P_ShortDescription", p_shortdescription));
                cmd.Parameters.Add(new SqlParameter("@P_DetailDescription", p_DetailDescription));
                cmd.Parameters.Add(new SqlParameter("@P_InvoiceDescription", p_InvoiceDescription));
                cmd.Parameters.Add(new SqlParameter("@P_SaleStartDate", p_SaleStartDate));
                cmd.Parameters.Add(new SqlParameter("@P_SaleEndDate", p_SaleEndDate));
                cmd.Parameters.Add(new SqlParameter("@P_Status", p_Status));
                cmd.Parameters.Add(new SqlParameter("@P_BrandName", p_BrandName));
                cmd.Parameters.Add(new SqlParameter("@P_Condition", p_Condition));
                cmd.Parameters.Add(new SqlParameter("@P_MaxOrderQuantity", p_MaxOrderQuantity));
                cmd.Parameters.Add(new SqlParameter("@P_UPC", p_upc));
                cmd.Parameters.Add(new SqlParameter("@P_UPC2", p_upc2));

                cmd.Parameters.Add(new SqlParameter("@P_Cost", p_cost));
                cmd.Parameters.Add(new SqlParameter("@P_GST", p_gst));
                cmd.Parameters.Add(new SqlParameter("@P_Taxtype", p_taxtype));
                cmd.Parameters.Add(new SqlParameter("@P_InclusiveTax", P_InclusiveTax));
                cmd.Parameters.Add(new SqlParameter("@P_ExclusiveTax", P_ExclusiveTax));
                cmd.Parameters.Add(new SqlParameter("@P_Markup", P_Markup));
                cmd.Parameters.Add(new SqlParameter("@P_SalePrice", P_SalePrice));

                cmd.Parameters.Add(new SqlParameter("@P_Quantity", P_Quantity));
                cmd.Parameters.Add(new SqlParameter("@P_RestockSDate", P_RestockSDate));
                cmd.Parameters.Add(new SqlParameter("@P_StockAvailability", P_StockAvailability));
                cmd.Parameters.Add(new SqlParameter("@P_SafetyStockLevel", P_SafetyStockLevel));
                cmd.Parameters.Add(new SqlParameter("@P_ReorderStockLevel", P_ReorderStockLevel));

                cmd.Parameters.Add(new SqlParameter("@P_Weight", P_Weight));
                cmd.Parameters.Add(new SqlParameter("@P_Length", P_Length));
                cmd.Parameters.Add(new SqlParameter("@P_Width", P_Width));
                cmd.Parameters.Add(new SqlParameter("@P_Height", P_Height));
                cmd.Parameters.Add(new SqlParameter("@P_Volume", P_Volume));
                cmd.Parameters.Add(new SqlParameter("@P_Wattage", P_Wattage));
                cmd.Parameters.Add(new SqlParameter("@P_WeightUnit", P_WeightUnit));
                cmd.Parameters.Add(new SqlParameter("@P_LengthUnit", P_LengthUnit));
                cmd.Parameters.Add(new SqlParameter("@P_WidthUnit", P_WidthUnit));
                cmd.Parameters.Add(new SqlParameter("@P_HeightUnit", P_HeightUnit));
                cmd.Parameters.Add(new SqlParameter("@P_VolumeUnit", P_VolumeUnit));
                cmd.Parameters.Add(new SqlParameter("@P_WattageUnit", P_WattageUnit));

                cmd.Parameters.Add(new SqlParameter("@P_NumberofPieces", P_NumberofPieces));
                cmd.Parameters.Add(new SqlParameter("@P_Shape", P_Shape));
                cmd.Parameters.Add(new SqlParameter("@P_IncludedComponents", P_IncludedComponents));
                cmd.Parameters.Add(new SqlParameter("@P_PackageQty", P_PackageQty));
                cmd.Parameters.Add(new SqlParameter("@P_SPackageLength", P_SPackageLength));
                cmd.Parameters.Add(new SqlParameter("@P_SPackageWidth", P_SPackageWidth));
                cmd.Parameters.Add(new SqlParameter("@P_SPackageHeight", P_SPackageHeight));

                cmd.Parameters.Add(new SqlParameter("@P_SPackageUnit", P_SPackageUnit));
                cmd.Parameters.Add(new SqlParameter("@P_SDepth", P_SDepth));
                cmd.Parameters.Add(new SqlParameter("@P_SDepthUnit", P_SDepthUnit));
                cmd.Parameters.Add(new SqlParameter("@P_Size", P_Size));
                cmd.Parameters.Add(new SqlParameter("@P_ShippingRateOption", P_ShippingRateOption));
                cmd.Parameters.Add(new SqlParameter("@P_ShippingPickupOption", P_ShippingPickupOption));
                cmd.Parameters.Add(new SqlParameter("@P_ShipptingTemplateID", P_ShipptingTemplateID));
                cmd.Parameters.Add(new SqlParameter("@P_SHandlingTime", P_SHandlingTime));

                cmd.Parameters.Add(new SqlParameter("@P_WareHouselocationID", P_WareHouselocationID));

                cmd.Parameters.Add(new SqlParameter("@P_VendorCategory", P_VendorCategory));
                cmd.Parameters.Add(new SqlParameter("@P_VendorName", P_VendorName));
                cmd.Parameters.Add(new SqlParameter("@P_VendorItemCode", P_VendorItemCode));
                cmd.Parameters.Add(new SqlParameter("@P_VenderPrice", P_VenderPrice));
                cmd.Parameters.Add(new SqlParameter("@P_VendorCurrency", P_VendorCurrency));
                cmd.Parameters.Add(new SqlParameter("@P_VenderLinkURL", P_VenderLinkURL));
                cmd.Parameters.Add(new SqlParameter("@P_PublicNotes", P_PublicNotes));

                cmd.Parameters.Add(new SqlParameter("@P_PrivateNotes", P_PrivateNotes));
                cmd.Parameters.Add(new SqlParameter("@P_Createdby", P_Createdby));
                cmd.Parameters.Add(new SqlParameter("@P_CreatedDatetime", P_CreatedDatetime));
                cmd.Parameters.Add(new SqlParameter("@P_ModifiedBy", P_ModifiedBy));
                cmd.Parameters.Add(new SqlParameter("@P_ModifiedDatetime", P_ModifiedDatetime));
                cmd.Parameters.Add(new SqlParameter("@P_Meta_KeyWords", P_Meta_KeyWords));
                cmd.Parameters.Add(new SqlParameter("@P_Meta_Description", P_Meta_Description));

                cmd.Parameters.Add(new SqlParameter("@Seller_ID", sellerID));
                cmd.Parameters.Add(new SqlParameter("@P_TM_Title", tmTitle));
                cmd.Parameters.Add(new SqlParameter("@P_TM_SubTitle", tmSubtitle));
                cmd.Parameters.Add(new SqlParameter("@P_TM_ShortDescription", tmShortDescription));
                cmd.Parameters.Add(new SqlParameter("@P_TM_DetailDescription", tmDetailDescription));
                cmd.Parameters.Add(new SqlParameter("@Channel_ID", channelID));
                cmd.Parameters.Add("@return_id", SqlDbType.Int).Direction = ParameterDirection.Output;

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return Convert.ToInt32(cmd.Parameters["@return_id"].Value);



            }
            catch (Exception ex)
            {
                //return dt;
            }

            finally
            {

                cmd.Dispose();
                connection.Close();
            }
            return Convert.ToInt32(cmd.Parameters["@return_id"].Value);

        }

        ////////////////////////////////////////// Add Product ///////////////////////////////////////////////////////////////////

        public void UpdateProduct(int P_ID, string p_category, string p_categoryPAth, string p_title, string p_subTitle, string p_partnumber, string p_shortdescription,

                               string p_DetailDescription, string p_InvoiceDescription, string p_SaleStartDate, string p_SaleEndDate, bool p_Status,

                               string p_BrandName, string p_Condition, float p_MaxOrderQuantity, string p_upc, string p_upc2,

                               float p_cost, float p_gst, string p_taxtype, float P_InclusiveTax, float P_ExclusiveTax, float P_Markup,

                               float P_SalePrice, float P_Quantity, DateTime P_RestockSDate, string P_StockAvailability, float P_SafetyStockLevel,

                               float P_ReorderStockLevel, float P_Weight, float P_Length, float P_Width, float P_Height, float P_Volume, float P_Wattage,

                               string P_WeightUnit, string P_LengthUnit, string P_WidthUnit, string P_HeightUnit, string P_VolumeUnit, string P_WattageUnit,

                               string P_NumberofPieces, string P_Shape, string P_IncludedComponents, string P_PackageQty, float P_SPackageLength, float P_SPackageWidth,

                               float P_SPackageHeight, string P_SPackageUnit, float P_SDepth, string P_SDepthUnit, string P_Size, string P_ShippingRateOption,

                               string P_ShippingPickupOption, int P_ShipptingTemplateID, float P_SHandlingTime, string P_WareHouselocationID, string P_VendorCategory,

                               string P_VendorName, string P_VendorItemCode, float P_VenderPrice, string P_VendorCurrency, string P_VenderLinkURL, string P_PublicNotes,

                               string P_PrivateNotes, string P_Createdby, DateTime P_CreatedDatetime, string P_ModifiedBy, DateTime P_ModifiedDatetime,

                               string P_Meta_KeyWords, string P_Meta_Description, int sellerID, string tmTitle, string tmSubtitle, string tmShortDescription,
                                string tmDetailDescription, int channelID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_UpdateProduct", connection);

                cmd.Parameters.Add(new SqlParameter("@P_ID", P_ID));
                cmd.Parameters.Add(new SqlParameter("@P_Category", p_category));
                cmd.Parameters.Add(new SqlParameter("@P_CategoryPath", p_categoryPAth));
                cmd.Parameters.Add(new SqlParameter("@P_Title", p_title));
                cmd.Parameters.Add(new SqlParameter("@P_SubTitle", p_subTitle));
                cmd.Parameters.Add(new SqlParameter("@P_PartNumber", p_partnumber));
                cmd.Parameters.Add(new SqlParameter("@P_ShortDescription", p_shortdescription));
                cmd.Parameters.Add(new SqlParameter("@P_DetailDescription", p_DetailDescription));
                cmd.Parameters.Add(new SqlParameter("@P_InvoiceDescription", p_InvoiceDescription));
                cmd.Parameters.Add(new SqlParameter("@P_SaleStartDate", p_SaleStartDate));
                cmd.Parameters.Add(new SqlParameter("@P_SaleEndDate", p_SaleEndDate));
                cmd.Parameters.Add(new SqlParameter("@P_Status", p_Status));
                cmd.Parameters.Add(new SqlParameter("@P_BrandName", p_BrandName));
                cmd.Parameters.Add(new SqlParameter("@P_Condition", p_Condition));
                cmd.Parameters.Add(new SqlParameter("@P_MaxOrderQuantity", p_MaxOrderQuantity));
                cmd.Parameters.Add(new SqlParameter("@P_UPC", p_upc));
                cmd.Parameters.Add(new SqlParameter("@P_UPC2", p_upc2));

                cmd.Parameters.Add(new SqlParameter("@P_Cost", p_cost));
                cmd.Parameters.Add(new SqlParameter("@P_GST", p_gst));
                cmd.Parameters.Add(new SqlParameter("@P_Taxtype", p_taxtype));
                cmd.Parameters.Add(new SqlParameter("@P_InclusiveTax", P_InclusiveTax));
                cmd.Parameters.Add(new SqlParameter("@P_ExclusiveTax", P_ExclusiveTax));
                cmd.Parameters.Add(new SqlParameter("@P_Markup", P_Markup));
                cmd.Parameters.Add(new SqlParameter("@P_SalePrice", P_SalePrice));

                cmd.Parameters.Add(new SqlParameter("@P_Quantity", P_Quantity));
                cmd.Parameters.Add(new SqlParameter("@P_RestockSDate", P_RestockSDate));
                cmd.Parameters.Add(new SqlParameter("@P_StockAvailability", P_StockAvailability));
                cmd.Parameters.Add(new SqlParameter("@P_SafetyStockLevel", P_SafetyStockLevel));
                cmd.Parameters.Add(new SqlParameter("@P_ReorderStockLevel", P_ReorderStockLevel));

                cmd.Parameters.Add(new SqlParameter("@P_Weight", P_Weight));
                cmd.Parameters.Add(new SqlParameter("@P_Length", P_Length));
                cmd.Parameters.Add(new SqlParameter("@P_Width", P_Width));
                cmd.Parameters.Add(new SqlParameter("@P_Height", P_Height));
                cmd.Parameters.Add(new SqlParameter("@P_Volume", P_Volume));
                cmd.Parameters.Add(new SqlParameter("@P_Wattage", P_Wattage));
                cmd.Parameters.Add(new SqlParameter("@P_WeightUnit", P_WeightUnit));
                cmd.Parameters.Add(new SqlParameter("@P_LengthUnit", P_LengthUnit));
                cmd.Parameters.Add(new SqlParameter("@P_WidthUnit", P_WidthUnit));
                cmd.Parameters.Add(new SqlParameter("@P_HeightUnit", P_HeightUnit));
                cmd.Parameters.Add(new SqlParameter("@P_VolumeUnit", P_VolumeUnit));
                cmd.Parameters.Add(new SqlParameter("@P_WattageUnit", P_WattageUnit));

                cmd.Parameters.Add(new SqlParameter("@P_NumberofPieces", P_NumberofPieces));
                cmd.Parameters.Add(new SqlParameter("@P_Shape", P_Shape));
                cmd.Parameters.Add(new SqlParameter("@P_IncludedComponents", P_IncludedComponents));
                cmd.Parameters.Add(new SqlParameter("@P_PackageQty", P_PackageQty));
                cmd.Parameters.Add(new SqlParameter("@P_SPackageLength", P_SPackageLength));
                cmd.Parameters.Add(new SqlParameter("@P_SPackageWidth", P_SPackageWidth));
                cmd.Parameters.Add(new SqlParameter("@P_SPackageHeight", P_SPackageHeight));

                cmd.Parameters.Add(new SqlParameter("@P_SPackageUnit", P_SPackageUnit));
                cmd.Parameters.Add(new SqlParameter("@P_SDepth", P_SDepth));
                cmd.Parameters.Add(new SqlParameter("@P_SDepthUnit", P_SDepthUnit));
                cmd.Parameters.Add(new SqlParameter("@P_Size", P_Size));
                cmd.Parameters.Add(new SqlParameter("@P_ShippingRateOption", P_ShippingRateOption));
                cmd.Parameters.Add(new SqlParameter("@P_ShippingPickupOption", P_ShippingPickupOption));
                cmd.Parameters.Add(new SqlParameter("@P_ShipptingTemplateID", P_ShipptingTemplateID));
                cmd.Parameters.Add(new SqlParameter("@P_SHandlingTime", P_SHandlingTime));

                cmd.Parameters.Add(new SqlParameter("@P_WareHouselocationID", P_WareHouselocationID));

                cmd.Parameters.Add(new SqlParameter("@P_VendorCategory", P_VendorCategory));
                cmd.Parameters.Add(new SqlParameter("@P_VendorName", P_VendorName));
                cmd.Parameters.Add(new SqlParameter("@P_VendorItemCode", P_VendorItemCode));
                cmd.Parameters.Add(new SqlParameter("@P_VenderPrice", P_VenderPrice));
                cmd.Parameters.Add(new SqlParameter("@P_VendorCurrency", P_VendorCurrency));
                cmd.Parameters.Add(new SqlParameter("@P_VenderLinkURL", P_VenderLinkURL));
                cmd.Parameters.Add(new SqlParameter("@P_PublicNotes", P_PublicNotes));

                cmd.Parameters.Add(new SqlParameter("@P_PrivateNotes", P_PrivateNotes));
                cmd.Parameters.Add(new SqlParameter("@P_Createdby", P_Createdby));
                cmd.Parameters.Add(new SqlParameter("@P_CreatedDatetime", P_CreatedDatetime));
                cmd.Parameters.Add(new SqlParameter("@P_ModifiedBy", P_ModifiedBy));
                cmd.Parameters.Add(new SqlParameter("@P_ModifiedDatetime", P_ModifiedDatetime));
                cmd.Parameters.Add(new SqlParameter("@P_Meta_KeyWords", P_Meta_KeyWords));
                cmd.Parameters.Add(new SqlParameter("@P_Meta_Description", P_Meta_Description));

                cmd.Parameters.Add(new SqlParameter("@Seller_ID", sellerID));
                cmd.Parameters.Add(new SqlParameter("@P_TM_Title", tmTitle));
                cmd.Parameters.Add(new SqlParameter("@P_TM_SubTitle", tmSubtitle));
                cmd.Parameters.Add(new SqlParameter("@P_TM_ShortDescription", tmShortDescription));
                cmd.Parameters.Add(new SqlParameter("@P_TM_DetailDescription", tmDetailDescription));
                cmd.Parameters.Add(new SqlParameter("@Channel_ID", channelID));



                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }


        public void AddProductImage(string ImageName, string ImageType, int ImageSize, int P_ID, int Seller_ID, int ImageSorting, bool IsFeature, int ImageWidth, int ImageHeight, bool IsactiveonAution, bool IsactiveonWebsite)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_AddProductImages", connection);

                cmd.Parameters.Add(new SqlParameter("@ImageName", ImageName));
                cmd.Parameters.Add(new SqlParameter("@ImageType", ImageType));
                cmd.Parameters.Add(new SqlParameter("@ImageSize", ImageSize));
                cmd.Parameters.Add(new SqlParameter("@P_ID", P_ID));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));
                cmd.Parameters.Add(new SqlParameter("@ImageSorting", ImageSorting));
                cmd.Parameters.Add(new SqlParameter("@IsFeature", IsFeature));
                cmd.Parameters.Add(new SqlParameter("@ImageWidth", ImageWidth));
                cmd.Parameters.Add(new SqlParameter("@ImageHeight", ImageHeight));
                cmd.Parameters.Add(new SqlParameter("@IsactiveonAution", IsactiveonAution));
                cmd.Parameters.Add(new SqlParameter("@IsactiveonWebsite", IsactiveonWebsite));


                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }






        ////////////////////////////////////// Add WareHouse ///////////////////////////////////////////////////////////////////

        public void AddWareHouse(string name, string description, int sellerID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_InsertWareHouse", connection);



                cmd.Parameters.Add(new SqlParameter("@Wh_Name", name));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", sellerID));
                //cmd.Parameters.Add(new SqlParameter("@Wh_Description", description));


                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }



        public void UpdateImageIsFeature(string type, bool status, int imgid, int P_ID, int Seller_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_UpdateImageStatus", connection);



                cmd.Parameters.Add(new SqlParameter("@type", type));
                cmd.Parameters.Add(new SqlParameter("@status", status));
                cmd.Parameters.Add(new SqlParameter("@imgid", imgid));
                cmd.Parameters.Add(new SqlParameter("@P_ID", P_ID));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));






                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }







        ////////////////////////////////////// Add Vendor ///////////////////////////////////////////////////////////////////

        public void AddVendor(string V_Name, string V_CompanyName, string V_City, string V_PostCode, string V_RegionState, string V_PhoneNo, string V_Fax,
                              string V_MobileNo, string V_Email, float V_DefaultTax, string V_Website, string V_ShippingInstructions, int V_IsShippingAddress,
                              string V_SName, string V_SCompanyName, string V_SCity, string V_SPostCode, string V_SRegionState, string V_SPhoneNo, string V_SFax,
                              string V_SMobileNo, string V_SEmail, bool IsVoid, int sellerID, string skypeid, string wechatid, string staffid)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_InsertVendor", connection);

                cmd.Parameters.Add(new SqlParameter("@V_Name", V_Name));
                cmd.Parameters.Add(new SqlParameter("@V_CompanyName", V_CompanyName));
                cmd.Parameters.Add(new SqlParameter("@V_City", V_City));
                cmd.Parameters.Add(new SqlParameter("@V_PostCode", V_PostCode));
                cmd.Parameters.Add(new SqlParameter("@V_RegionState", V_RegionState));
                cmd.Parameters.Add(new SqlParameter("@V_PhoneNo", V_PhoneNo));
                cmd.Parameters.Add(new SqlParameter("@V_Fax", V_Fax));
                cmd.Parameters.Add(new SqlParameter("@V_MobileNo", V_MobileNo));
                cmd.Parameters.Add(new SqlParameter("@V_Email", V_Email));
                cmd.Parameters.Add(new SqlParameter("@V_DefaultTax", V_DefaultTax));
                cmd.Parameters.Add(new SqlParameter("@V_Website", V_Website));
                cmd.Parameters.Add(new SqlParameter("@V_ShippingInstructions", V_ShippingInstructions));
                cmd.Parameters.Add(new SqlParameter("@V_IsShippingAddress", V_IsShippingAddress));
                cmd.Parameters.Add(new SqlParameter("@V_SName", V_SName));
                cmd.Parameters.Add(new SqlParameter("@V_SCompanyName", V_SCompanyName));
                cmd.Parameters.Add(new SqlParameter("@V_SCity", V_SCity));
                cmd.Parameters.Add(new SqlParameter("@V_SPostCode", V_SPostCode));
                cmd.Parameters.Add(new SqlParameter("@V_SRegionState", V_SRegionState));
                cmd.Parameters.Add(new SqlParameter("@V_SPhoneNo", V_SPhoneNo));
                cmd.Parameters.Add(new SqlParameter("@V_SFax", V_SFax));
                cmd.Parameters.Add(new SqlParameter("@V_SMobileNo", V_SMobileNo));
                cmd.Parameters.Add(new SqlParameter("@V_SEmail", V_SEmail));
                cmd.Parameters.Add(new SqlParameter("@IsVoid", IsVoid));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", sellerID));

                cmd.Parameters.Add(new SqlParameter("@skypeid", skypeid));
                cmd.Parameters.Add(new SqlParameter("@wechatid", wechatid));
                cmd.Parameters.Add(new SqlParameter("@staffid", staffid));
                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }

        ////////////////////////////////////// Update Vendor ///////////////////////////////////////////////////////////////////

        public void UpdateVendor(int ID, string V_Name, string V_CompanyName, string V_City, string V_PostCode, string V_RegionState, string V_PhoneNo, string V_Fax,
                              string V_MobileNo, string V_Email, float V_DefaultTax, string V_Website, string V_ShippingInstructions, int V_IsShippingAddress,
                              string V_SName, string V_SCompanyName, string V_SCity, string V_SPostCode, string V_SRegionState, string V_SPhoneNo, string V_SFax,
                              string V_SMobileNo, string V_SEmail, bool IsVoid, int sellerID, string skypeid, string wechatid, string staffid)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_UpdateVendor", connection);

                cmd.Parameters.Add(new SqlParameter("@V_ID", ID));
                cmd.Parameters.Add(new SqlParameter("@V_Name", V_Name));
                cmd.Parameters.Add(new SqlParameter("@V_CompanyName", V_CompanyName));
                cmd.Parameters.Add(new SqlParameter("@V_City", V_City));
                cmd.Parameters.Add(new SqlParameter("@V_PostCode", V_PostCode));
                cmd.Parameters.Add(new SqlParameter("@V_RegionState", V_RegionState));
                cmd.Parameters.Add(new SqlParameter("@V_PhoneNo", V_PhoneNo));
                cmd.Parameters.Add(new SqlParameter("@V_Fax", V_Fax));
                cmd.Parameters.Add(new SqlParameter("@V_MobileNo", V_MobileNo));
                cmd.Parameters.Add(new SqlParameter("@V_Email", V_Email));
                cmd.Parameters.Add(new SqlParameter("@V_DefaultTax", V_DefaultTax));
                cmd.Parameters.Add(new SqlParameter("@V_Website", V_Website));
                cmd.Parameters.Add(new SqlParameter("@V_ShippingInstructions", V_ShippingInstructions));
                cmd.Parameters.Add(new SqlParameter("@V_IsShippingAddress", V_IsShippingAddress));
                cmd.Parameters.Add(new SqlParameter("@V_SName", V_SName));
                cmd.Parameters.Add(new SqlParameter("@V_SCompanyName", V_SCompanyName));
                cmd.Parameters.Add(new SqlParameter("@V_SCity", V_SCity));
                cmd.Parameters.Add(new SqlParameter("@V_SPostCode", V_SPostCode));
                cmd.Parameters.Add(new SqlParameter("@V_SRegionState", V_SRegionState));
                cmd.Parameters.Add(new SqlParameter("@V_SPhoneNo", V_SPhoneNo));
                cmd.Parameters.Add(new SqlParameter("@V_SFax", V_SFax));
                cmd.Parameters.Add(new SqlParameter("@V_SMobileNo", V_SMobileNo));
                cmd.Parameters.Add(new SqlParameter("@V_SEmail", V_SEmail));
                cmd.Parameters.Add(new SqlParameter("@IsVoid", IsVoid));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", sellerID));
                cmd.Parameters.Add(new SqlParameter("@skypeid", skypeid));
                cmd.Parameters.Add(new SqlParameter("@wechatid", wechatid));
                cmd.Parameters.Add(new SqlParameter("@staffid", staffid));
                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }

        ////////////////////////////////////// Update Warehouse ///////////////////////////////////////////////////////////////////

        public void UpdateWarehouse(int ID, string name, int sellerID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_UpdateWarehuose", connection);

                cmd.Parameters.Add(new SqlParameter("@Wh_ID", ID));
                cmd.Parameters.Add(new SqlParameter("@Wh_Name", name));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", sellerID));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }

        ////////////////////////////////////// Update TradeMe ///////////////////////////////////////////////////////////////////

        public int AddUpdateAution(int ProductID, int sellerID, int Channel_ID, string PartNumber, string UPC1, string UPC2, string RuleName, bool IsUseCategoryMap, string CategoryID, string MapCategoryPath, string CategoryName, float Promotion_TrademeFee, bool Pro_AutoGalleryPlus, bool Pro_GalleryPlus, bool Pro_Gallery, bool Pro_Feature, bool Pro_Featurecombo, bool Pro_Homepage, bool IsReservedStockforAution, int ListingPriority, bool AllowBidingAnyOneorAuthUser, bool IsSetLitingLimit, int ListingLimitValue, string SetTitle, bool IsActiveSubTitle, string SetSubTitle, string SetDescription, int ListingIsStandarBuyNowQtyBNow, int ListingTypeFixedorDynamic, bool IsEnableBuyNow, bool IsEnableOffer, float PriceBuyNow, float PriceStart, float PriceReserved, float PriceOffer, float CostExGST, float CostIncGST, float PriceBuyNowMarkup, float PriceStartMarkup, float PriceReservedMarkup, float PriceOfferMarkup, bool EnableWasPrice, float PriceWas, float WasPriceDiscount, float AvailableStockforAution, int IsFlatRateShippingorPerItem, bool IsOfferRelativetoAuctionPrice, float PriceOfferRelativetoAuction, string AdvanceFixedPriceOfferLength, int OnStockLow_FixedPOorPovernewList, int AutionLengthType, int AutionLength, int TimingAutionTimingType, int TimingNumbertoMaintain, string TimingSpecificTimeHours, string TimingSpecificTimeDay, bool AutionStatus, string StatusRoleType, bool IsPictureGalleryDefault, bool IsEasyWholeSaleShipping, string CreatedUser, DateTime CreatedDateTime, string ProductName)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_AddUpdateTradeMeAution", connection);
                cmd.Parameters.Add(new SqlParameter("@ProductID", ProductID));
                cmd.Parameters.Add(new SqlParameter("@sellerID", sellerID));
                cmd.Parameters.Add(new SqlParameter("@Channel_ID", Channel_ID));
                cmd.Parameters.Add(new SqlParameter("@PartNumber", PartNumber));
                cmd.Parameters.Add(new SqlParameter("@UPC1", UPC1));
                cmd.Parameters.Add(new SqlParameter("@UPC2", UPC2));
                cmd.Parameters.Add(new SqlParameter("@RuleName", RuleName));
                cmd.Parameters.Add(new SqlParameter("@IsUseCategoryMap", IsUseCategoryMap));
                cmd.Parameters.Add(new SqlParameter("@CategoryID", CategoryID));
                cmd.Parameters.Add(new SqlParameter("@MapCategoryPath", MapCategoryPath));
                cmd.Parameters.Add(new SqlParameter("@CategoryName", CategoryName));
                cmd.Parameters.Add(new SqlParameter("@Promotion_TrademeFee", Promotion_TrademeFee));
                cmd.Parameters.Add(new SqlParameter("@Pro_AutoGalleryPlus", Pro_AutoGalleryPlus));
                cmd.Parameters.Add(new SqlParameter("@Pro_GalleryPlus", Pro_GalleryPlus));
                cmd.Parameters.Add(new SqlParameter("@Pro_Gallery", Pro_Gallery));
                cmd.Parameters.Add(new SqlParameter("@Pro_Feature", Pro_Feature));
                cmd.Parameters.Add(new SqlParameter("@Pro_Featurecombo", Pro_Featurecombo));
                cmd.Parameters.Add(new SqlParameter("@Pro_Homepage", Pro_Homepage));
                cmd.Parameters.Add(new SqlParameter("@IsReservedStockforAution", IsReservedStockforAution));
                cmd.Parameters.Add(new SqlParameter("@ListingPriority", ListingPriority));
                cmd.Parameters.Add(new SqlParameter("@AllowBidingAnyOneorAuthUser", AllowBidingAnyOneorAuthUser));
                cmd.Parameters.Add(new SqlParameter("@IsSetLitingLimit", IsSetLitingLimit));
                cmd.Parameters.Add(new SqlParameter("@ListingLimitValue", ListingLimitValue));
                cmd.Parameters.Add(new SqlParameter("@SetTitle", SetTitle));
                cmd.Parameters.Add(new SqlParameter("@IsActiveSubTitle", IsActiveSubTitle));
                cmd.Parameters.Add(new SqlParameter("@SetSubTitle", SetSubTitle));
                cmd.Parameters.Add(new SqlParameter("@SetDescription", SetDescription));
                cmd.Parameters.Add(new SqlParameter("@ListingIsStandarBuyNowQtyBNow", ListingIsStandarBuyNowQtyBNow));
                cmd.Parameters.Add(new SqlParameter("@ListingTypeFixedorDynamic", ListingTypeFixedorDynamic));
                cmd.Parameters.Add(new SqlParameter("@IsEnableBuyNow", IsEnableBuyNow));
                cmd.Parameters.Add(new SqlParameter("@IsEnableOffer", IsEnableOffer));
                cmd.Parameters.Add(new SqlParameter("@PriceBuyNow", PriceBuyNow));
                cmd.Parameters.Add(new SqlParameter("@PriceStart", PriceStart));
                cmd.Parameters.Add(new SqlParameter("@PriceReserved", PriceReserved));
                cmd.Parameters.Add(new SqlParameter("@PriceOffer", PriceOffer));
                cmd.Parameters.Add(new SqlParameter("@CostExGST", CostExGST));
                cmd.Parameters.Add(new SqlParameter("@CostIncGST", CostIncGST));
                cmd.Parameters.Add(new SqlParameter("@PriceBuyNowMarkup", PriceBuyNowMarkup));
                cmd.Parameters.Add(new SqlParameter("@PriceStartMarkup", PriceStartMarkup));
                cmd.Parameters.Add(new SqlParameter("@PriceReservedMarkup", PriceReservedMarkup));
                cmd.Parameters.Add(new SqlParameter("@PriceOfferMarkup", PriceOfferMarkup));
                cmd.Parameters.Add(new SqlParameter("@EnableWasPrice", EnableWasPrice));
                cmd.Parameters.Add(new SqlParameter("@PriceWas", PriceWas));
                cmd.Parameters.Add(new SqlParameter("@WasPriceDiscount", WasPriceDiscount));
                cmd.Parameters.Add(new SqlParameter("@AvailableStockforAution", AvailableStockforAution));
                cmd.Parameters.Add(new SqlParameter("@IsFlatRateShippingorPerItem", IsFlatRateShippingorPerItem));
                cmd.Parameters.Add(new SqlParameter("@IsOfferRelativetoAuctionPrice", IsOfferRelativetoAuctionPrice));
                cmd.Parameters.Add(new SqlParameter("@PriceOfferRelativetoAuction", PriceOfferRelativetoAuction));
                cmd.Parameters.Add(new SqlParameter("@AdvanceFixedPriceOfferLength", AdvanceFixedPriceOfferLength));
                cmd.Parameters.Add(new SqlParameter("@OnStockLow_FixedPOorPovernewList", OnStockLow_FixedPOorPovernewList));
                cmd.Parameters.Add(new SqlParameter("@AutionLengthType", AutionLengthType));
                cmd.Parameters.Add(new SqlParameter("@AutionLength", AutionLength));
                cmd.Parameters.Add(new SqlParameter("@TimingAutionTimingType", TimingAutionTimingType));
                cmd.Parameters.Add(new SqlParameter("@TimingNumbertoMaintain", TimingNumbertoMaintain));
                cmd.Parameters.Add(new SqlParameter("@TimingSpecificTimeHours", TimingSpecificTimeHours));
                cmd.Parameters.Add(new SqlParameter("@TimingSpecificTimeDay", TimingSpecificTimeDay));
                cmd.Parameters.Add(new SqlParameter("@AutionStatus", AutionStatus));
                cmd.Parameters.Add(new SqlParameter("@StatusRoleType", StatusRoleType));
                cmd.Parameters.Add(new SqlParameter("@IsPictureGalleryDefault", IsPictureGalleryDefault));
                cmd.Parameters.Add(new SqlParameter("@IsEasyWholeSaleShipping", IsEasyWholeSaleShipping));
                cmd.Parameters.Add(new SqlParameter("@CreatedUser", CreatedUser));
                cmd.Parameters.Add(new SqlParameter("@CreatedDateTime", CreatedDateTime));
                cmd.Parameters.Add(new SqlParameter("@ProductName", ProductName));
                cmd.Parameters.Add("@return_id", SqlDbType.Int).Direction = ParameterDirection.Output;

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);
                return Convert.ToInt32(cmd.Parameters["@return_id"].Value);
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();

            }
            return Convert.ToInt32(cmd.Parameters["@return_id"].Value);
        }



        public int UpdateTradeMeAution(int AutionID, int ProductID, int sellerID, int Channel_ID, string PartNumber, string UPC1, string UPC2, string RuleName, bool IsUseCategoryMap, string CategoryID, string MapCategoryPath, string CategoryName, float Promotion_TrademeFee, bool Pro_AutoGalleryPlus, bool Pro_GalleryPlus, bool Pro_Gallery, bool Pro_Feature, bool Pro_Featurecombo, bool Pro_Homepage, bool IsReservedStockforAution, int ListingPriority, bool AllowBidingAnyOneorAuthUser, bool IsSetLitingLimit, int ListingLimitValue, string SetTitle, bool IsActiveSubTitle, string SetSubTitle, string SetDescription, int ListingIsStandarBuyNowQtyBNow, int ListingTypeFixedorDynamic, bool IsEnableBuyNow, bool IsEnableOffer, float PriceBuyNow, float PriceStart, float PriceReserved, float PriceOffer, float CostExGST, float CostIncGST, float PriceBuyNowMarkup, float PriceStartMarkup, float PriceReservedMarkup, float PriceOfferMarkup, bool EnableWasPrice, float PriceWas, float WasPriceDiscount, float AvailableStockforAution, int IsFlatRateShippingorPerItem, bool IsOfferRelativetoAuctionPrice, float PriceOfferRelativetoAuction, string AdvanceFixedPriceOfferLength, int OnStockLow_FixedPOorPovernewList, int AutionLengthType, int AutionLength, int TimingAutionTimingType, int TimingNumbertoMaintain, string TimingSpecificTimeHours, string TimingSpecificTimeDay, bool AutionStatus, string StatusRoleType, bool IsPictureGalleryDefault, bool IsEasyWholeSaleShipping, string CreatedUser, DateTime CreatedDateTime, string ProductName)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_UpdateTradeMeAution", connection);
                cmd.Parameters.Add(new SqlParameter("@AutionID", AutionID));
                cmd.Parameters.Add(new SqlParameter("@ProductID", ProductID));
                cmd.Parameters.Add(new SqlParameter("@sellerID", sellerID));
                cmd.Parameters.Add(new SqlParameter("@Channel_ID", Channel_ID));
                cmd.Parameters.Add(new SqlParameter("@PartNumber", PartNumber));
                cmd.Parameters.Add(new SqlParameter("@UPC1", UPC1));
                cmd.Parameters.Add(new SqlParameter("@UPC2", UPC2));
                cmd.Parameters.Add(new SqlParameter("@RuleName", RuleName));
                cmd.Parameters.Add(new SqlParameter("@IsUseCategoryMap", IsUseCategoryMap));
                cmd.Parameters.Add(new SqlParameter("@CategoryID", CategoryID));
                cmd.Parameters.Add(new SqlParameter("@MapCategoryPath", MapCategoryPath));
                cmd.Parameters.Add(new SqlParameter("@CategoryName", CategoryName));
                cmd.Parameters.Add(new SqlParameter("@Promotion_TrademeFee", Promotion_TrademeFee));
                cmd.Parameters.Add(new SqlParameter("@Pro_AutoGalleryPlus", Pro_AutoGalleryPlus));
                cmd.Parameters.Add(new SqlParameter("@Pro_GalleryPlus", Pro_GalleryPlus));
                cmd.Parameters.Add(new SqlParameter("@Pro_Gallery", Pro_Gallery));
                cmd.Parameters.Add(new SqlParameter("@Pro_Feature", Pro_Feature));
                cmd.Parameters.Add(new SqlParameter("@Pro_Featurecombo", Pro_Featurecombo));
                cmd.Parameters.Add(new SqlParameter("@Pro_Homepage", Pro_Homepage));
                cmd.Parameters.Add(new SqlParameter("@IsReservedStockforAution", IsReservedStockforAution));
                cmd.Parameters.Add(new SqlParameter("@ListingPriority", ListingPriority));
                cmd.Parameters.Add(new SqlParameter("@AllowBidingAnyOneorAuthUser", AllowBidingAnyOneorAuthUser));
                cmd.Parameters.Add(new SqlParameter("@IsSetLitingLimit", IsSetLitingLimit));
                cmd.Parameters.Add(new SqlParameter("@ListingLimitValue", ListingLimitValue));
                cmd.Parameters.Add(new SqlParameter("@SetTitle", SetTitle));
                cmd.Parameters.Add(new SqlParameter("@IsActiveSubTitle", IsActiveSubTitle));
                cmd.Parameters.Add(new SqlParameter("@SetSubTitle", SetSubTitle));
                cmd.Parameters.Add(new SqlParameter("@SetDescription", SetDescription));
                cmd.Parameters.Add(new SqlParameter("@ListingIsStandarBuyNowQtyBNow", ListingIsStandarBuyNowQtyBNow));
                cmd.Parameters.Add(new SqlParameter("@ListingTypeFixedorDynamic", ListingTypeFixedorDynamic));
                cmd.Parameters.Add(new SqlParameter("@IsEnableBuyNow", IsEnableBuyNow));
                cmd.Parameters.Add(new SqlParameter("@IsEnableOffer", IsEnableOffer));
                cmd.Parameters.Add(new SqlParameter("@PriceBuyNow", PriceBuyNow));
                cmd.Parameters.Add(new SqlParameter("@PriceStart", PriceStart));
                cmd.Parameters.Add(new SqlParameter("@PriceReserved", PriceReserved));
                cmd.Parameters.Add(new SqlParameter("@PriceOffer", PriceOffer));
                cmd.Parameters.Add(new SqlParameter("@CostExGST", CostExGST));
                cmd.Parameters.Add(new SqlParameter("@CostIncGST", CostIncGST));
                cmd.Parameters.Add(new SqlParameter("@PriceBuyNowMarkup", PriceBuyNowMarkup));
                cmd.Parameters.Add(new SqlParameter("@PriceStartMarkup", PriceStartMarkup));
                cmd.Parameters.Add(new SqlParameter("@PriceReservedMarkup", PriceReservedMarkup));
                cmd.Parameters.Add(new SqlParameter("@PriceOfferMarkup", PriceOfferMarkup));
                cmd.Parameters.Add(new SqlParameter("@EnableWasPrice", EnableWasPrice));
                cmd.Parameters.Add(new SqlParameter("@PriceWas", PriceWas));
                cmd.Parameters.Add(new SqlParameter("@WasPriceDiscount", WasPriceDiscount));
                cmd.Parameters.Add(new SqlParameter("@AvailableStockforAution", AvailableStockforAution));
                cmd.Parameters.Add(new SqlParameter("@IsFlatRateShippingorPerItem", IsFlatRateShippingorPerItem));
                cmd.Parameters.Add(new SqlParameter("@IsOfferRelativetoAuctionPrice", IsOfferRelativetoAuctionPrice));
                cmd.Parameters.Add(new SqlParameter("@PriceOfferRelativetoAuction", PriceOfferRelativetoAuction));
                cmd.Parameters.Add(new SqlParameter("@AdvanceFixedPriceOfferLength", AdvanceFixedPriceOfferLength));
                cmd.Parameters.Add(new SqlParameter("@OnStockLow_FixedPOorPovernewList", OnStockLow_FixedPOorPovernewList));
                cmd.Parameters.Add(new SqlParameter("@AutionLengthType", AutionLengthType));
                cmd.Parameters.Add(new SqlParameter("@AutionLength", AutionLength));
                cmd.Parameters.Add(new SqlParameter("@TimingAutionTimingType", TimingAutionTimingType));
                cmd.Parameters.Add(new SqlParameter("@TimingNumbertoMaintain", TimingNumbertoMaintain));
                cmd.Parameters.Add(new SqlParameter("@TimingSpecificTimeHours", TimingSpecificTimeHours));
                cmd.Parameters.Add(new SqlParameter("@TimingSpecificTimeDay", TimingSpecificTimeDay));
                cmd.Parameters.Add(new SqlParameter("@AutionStatus", AutionStatus));
                cmd.Parameters.Add(new SqlParameter("@StatusRoleType", StatusRoleType));
                cmd.Parameters.Add(new SqlParameter("@IsPictureGalleryDefault", IsPictureGalleryDefault));

                cmd.Parameters.Add(new SqlParameter("@IsEasyWholeSaleShipping", IsEasyWholeSaleShipping));
                cmd.Parameters.Add(new SqlParameter("@CreatedUser", CreatedUser));
                cmd.Parameters.Add(new SqlParameter("@CreatedDateTime", CreatedDateTime));
                cmd.Parameters.Add(new SqlParameter("@ProductName", ProductName));


                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);
                return 1;
            }
            catch (Exception ex)
            {
                return 0;
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();

            }

            return 1;
        }












        public DataTable AutionListbyProduct(int PID, int sellerID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_TradeMeAutionListbyProductID", con);


                cmd.Parameters.Add(new SqlParameter("@ProductID", PID));
                cmd.Parameters.Add(new SqlParameter("@sellerID", sellerID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }



        public void AddUpateAutionImages(int ID, int Seller_ID, int Channel_ID, int TM_ID, string ImageURL, int ProductImageID, string ImageName, string ImageType, bool IsFeature, string PhotoData)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_AddUpdateAutionImage", connection);

                cmd.Parameters.Add(new SqlParameter("@ID", ID));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));
                cmd.Parameters.Add(new SqlParameter("@Channel_ID", Channel_ID));
                cmd.Parameters.Add(new SqlParameter("@TM_ID", TM_ID));
                cmd.Parameters.Add(new SqlParameter("@ImageURL", ImageURL));
                cmd.Parameters.Add(new SqlParameter("@ProductImageID", ProductImageID));
                cmd.Parameters.Add(new SqlParameter("@ImageName", ImageName));
                cmd.Parameters.Add(new SqlParameter("@ImageType", ImageType));
                cmd.Parameters.Add(new SqlParameter("@IsFeature", IsFeature));
                cmd.Parameters.Add(new SqlParameter("@PhotoData", PhotoData));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }





        /////////////////////////////////////////////////////////////////////// Get Product List/////////////////////////////
        public DataTable FetchProducts(int sellerID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetProducts", con);
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", sellerID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable GetFeatureImagebyProductID(int ProductID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetFeatureImagebyProductID", con);

                cmd.Parameters.Add(new SqlParameter("@ProductID", ProductID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable BindProductImagesbyID(int sellerID, int ProductID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_BindProductImagesbyID", con);
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", sellerID));
                cmd.Parameters.Add(new SqlParameter("@ProductID", ProductID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }














        /////////////////////////////////////////////////////////////////////// Get Vendors List/////////////////////////////
        public DataTable FetchVendors(int sellerID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetVendors", con);
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", sellerID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable FetchCustomers(int sellerID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetCustomersList", con);
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", sellerID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }





        public DataTable GetProductImageName(int sellerID, int P_ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetProductImageName", con);
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", sellerID));
                cmd.Parameters.Add(new SqlParameter("@P_ID", P_ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }



        /////////////////////////////////////////////////////////////////////// Get UPC List/////////////////////////////
        public DataTable FetchUPC(int sellerID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetProductUPC", con);
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", sellerID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable FetchPartNumber(int sellerID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetPartNumber", con);
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", sellerID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }



        /////////////////////////////////////////////////////////////////////// Get Customer ID/////////////////////////////
        public DataTable GetCustomerIDbyUserName(string username)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetCustomerIDbyUserName", con);
                cmd.Parameters.Add(new SqlParameter("@username", username));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }




        /////////////////////////////////////////////////////////////////////// Get PO By id/////////////////////////////
        public DataTable getPOByID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetPOByID", con);
                cmd.Parameters.Add(new SqlParameter("@PO_ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        /////////////////////////////////////////////////////////////////////// Get Sale Order By id/////////////////////////////
        public DataTable getSOByID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetSOByID", con);
                cmd.Parameters.Add(new SqlParameter("@SO_ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }



        /////////////////////////////////////////////////////////////////////// Get PO Items Grid List/////////////////////////////
        public DataTable FetchPOItemGrid(int POId)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetPOItems", con);
                cmd.Parameters.Add(new SqlParameter("@PO_ID", POId));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }



        public DataTable FetchSOItemGrid(int SOId)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetSOItems", con);
                cmd.Parameters.Add(new SqlParameter("@SO_ID", SOId));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }






        public DataTable GetPOItemForCSV(int POId)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetPOItemForCSV", con);
                cmd.Parameters.Add(new SqlParameter("@PO_ID", POId));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable GetTotalPaidAmountofPO(int POId)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetTotalPaidAmountofPO", con);
                cmd.Parameters.Add(new SqlParameter("@PO_ID", POId));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }



        /////////////////////////////////////////////////////////////////////// Get PO Payment Grid List/////////////////////////////
        public DataTable FetchPOpaymentGrid(int POId)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetPOPayments", con);
                cmd.Parameters.Add(new SqlParameter("@PO_ID", POId));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        ////////////////////////////////////// Add Purchase Order ///////////////////////////////////////////////////////////////////

        public void UpdatePurchaseOrder(int POId, string PO_Title, int V_ID, string V_Name, int PO_IscashPurchase, string PO_Type, string PO_Date, string PO_DueDate, string PO_ReceivedDate, string PO_Note, string PO_InvoiceNo, string PO_Status,

                                    string PO_PaidStatus, string PO_StatusDate, string PO_Assignto, string PO_TrackingID, float PO_TotalAmount, float PO_Discount, float PO_TaxAmount, float PO_TaxType, float PO_TaxinPercentage, int PO_IsImportedAmount,
                                    float PO_ImportedLocalAmount, float PO_ImportedFreightAmount, string PO_SpecialInstructions, string PO_PrintingInstructions, string PO_CreatedBy, int PO_IsDefaultShipmentAddress, string PO_SA_Name, string PO_SA_CompanyName,
                                    string PO_SA_Address, string PO_SA_City, string PO_SA_PostCode, string PO_SA_Region, string PO_SA_Country, string PO_SA_SpecialInstructions, string PO_SA_Phone, string PO_SA_Mobile, string PO_SA_Email)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_UpdatePO", connection);

                cmd.Parameters.Add(new SqlParameter("@PO_ID", POId));
                cmd.Parameters.Add(new SqlParameter("@PO_Title", PO_Title));
                cmd.Parameters.Add(new SqlParameter("@V_ID", V_ID));
                cmd.Parameters.Add(new SqlParameter("@V_Name", V_Name));
                cmd.Parameters.Add(new SqlParameter("@PO_IsCashPurchase", PO_IscashPurchase));
                cmd.Parameters.Add(new SqlParameter("@PO_Type", PO_Type));
                cmd.Parameters.Add(new SqlParameter("@PO_Date", PO_Date));
                cmd.Parameters.Add(new SqlParameter("@PO_DueDate", PO_DueDate));
                cmd.Parameters.Add(new SqlParameter("@PO_ReceivedDate", PO_ReceivedDate));
                cmd.Parameters.Add(new SqlParameter("@PO_Note", PO_Note));
                cmd.Parameters.Add(new SqlParameter("@PO_InvoiceNo", PO_InvoiceNo));
                cmd.Parameters.Add(new SqlParameter("@PO_Status", PO_Status));
                cmd.Parameters.Add(new SqlParameter("@PO_PaidStatus", PO_PaidStatus));
                cmd.Parameters.Add(new SqlParameter("@PO_StatusDate", PO_StatusDate));
                cmd.Parameters.Add(new SqlParameter("@PO_Assignto", PO_Assignto));
                cmd.Parameters.Add(new SqlParameter("@PO_TrackingID", PO_TrackingID));
                cmd.Parameters.Add(new SqlParameter("@PO_TotalAmount", PO_TotalAmount));
                cmd.Parameters.Add(new SqlParameter("@PO_Discount", PO_Discount));
                cmd.Parameters.Add(new SqlParameter("@PO_TaxAmount", PO_TaxAmount));
                cmd.Parameters.Add(new SqlParameter("@PO_TaxType", PO_TaxType));
                cmd.Parameters.Add(new SqlParameter("@PO_TaxinPercentage", PO_TaxinPercentage));
                cmd.Parameters.Add(new SqlParameter("@PO_IsImportedAmount", PO_IsImportedAmount));
                cmd.Parameters.Add(new SqlParameter("@PO_ImportedLocalAmount", PO_ImportedLocalAmount));
                cmd.Parameters.Add(new SqlParameter("@PO_ImportedFreightAmount", PO_ImportedFreightAmount));
                cmd.Parameters.Add(new SqlParameter("@PO_SpecialInstructions", PO_SpecialInstructions));
                cmd.Parameters.Add(new SqlParameter("@PO_PrintingInstructions", PO_PrintingInstructions));
                cmd.Parameters.Add(new SqlParameter("@PO_CreatedBy", PO_CreatedBy));
                cmd.Parameters.Add(new SqlParameter("@PO_IsDefaultShipmentAddress", PO_IsDefaultShipmentAddress));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Name", PO_SA_Name));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_CompanyName", PO_SA_CompanyName));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Address", PO_SA_Address));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_City", PO_SA_City));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_PostCode", PO_SA_PostCode));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Region", PO_SA_Region));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Country", PO_SA_Country));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_SpecialInstructions", PO_SA_SpecialInstructions));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Phone", PO_SA_Phone));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Mobile", PO_SA_Mobile));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Email", PO_SA_Email));



                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);


            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }


        public void UpdateSaleOrder(string POId, string PO_Title, int PO_IscashPurchase, string PO_Type, string PO_Date, string PO_DueDate, string PO_ReceivedDate, string PO_Note, string PO_Status,

                                    string PO_PaidStatus, string PO_StatusDate, string PO_Assignto, string PO_TrackingID, float PO_TotalAmount, float PO_Discount, float PO_TaxAmount, float PO_TaxType, float PO_TaxinPercentage, int PO_IsImportedAmount,
                                    float PO_ImportedLocalAmount, float PO_ImportedFreightAmount, string PO_SpecialInstructions, string PO_PrintingInstructions, string PO_CreatedBy, int PO_IsDefaultShipmentAddress, string PO_SA_Name, string PO_SA_CompanyName,
                                    string PO_SA_Address, string PO_SA_City, string PO_SA_PostCode, string PO_SA_Region, string PO_SA_Country, string PO_SA_SpecialInstructions, string PO_SA_Phone, string PO_SA_Mobile, string PO_SA_Email)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_UpdateSaleOrder", connection);

                cmd.Parameters.Add(new SqlParameter("@OrderID", POId));
                cmd.Parameters.Add(new SqlParameter("@PO_Title", PO_Title));
                cmd.Parameters.Add(new SqlParameter("@PO_IsCashPurchase", PO_IscashPurchase));
                cmd.Parameters.Add(new SqlParameter("@PO_Type", PO_Type));
                cmd.Parameters.Add(new SqlParameter("@PO_Date", PO_Date));
                cmd.Parameters.Add(new SqlParameter("@PO_DueDate", PO_DueDate));
                cmd.Parameters.Add(new SqlParameter("@PO_ReceivedDate", PO_ReceivedDate));
                cmd.Parameters.Add(new SqlParameter("@PO_Note", PO_Note));

                cmd.Parameters.Add(new SqlParameter("@PO_Status", PO_Status));
                cmd.Parameters.Add(new SqlParameter("@PO_PaidStatus", PO_PaidStatus));
                cmd.Parameters.Add(new SqlParameter("@PO_StatusDate", PO_StatusDate));
                cmd.Parameters.Add(new SqlParameter("@PO_Assignto", PO_Assignto));
                cmd.Parameters.Add(new SqlParameter("@PO_TrackingID", PO_TrackingID));
                cmd.Parameters.Add(new SqlParameter("@PO_TotalAmount", PO_TotalAmount));
                cmd.Parameters.Add(new SqlParameter("@PO_Discount", PO_Discount));
                cmd.Parameters.Add(new SqlParameter("@PO_TaxAmount", PO_TaxAmount));
                cmd.Parameters.Add(new SqlParameter("@PO_TaxType", PO_TaxType));
                cmd.Parameters.Add(new SqlParameter("@PO_TaxinPercentage", PO_TaxinPercentage));
                cmd.Parameters.Add(new SqlParameter("@PO_IsImportedAmount", PO_IsImportedAmount));
                cmd.Parameters.Add(new SqlParameter("@PO_ImportedLocalAmount", PO_ImportedLocalAmount));
                cmd.Parameters.Add(new SqlParameter("@PO_ImportedFreightAmount", PO_ImportedFreightAmount));
                cmd.Parameters.Add(new SqlParameter("@PO_SpecialInstructions", PO_SpecialInstructions));
                cmd.Parameters.Add(new SqlParameter("@PO_PrintingInstructions", PO_PrintingInstructions));
                cmd.Parameters.Add(new SqlParameter("@PO_CreatedBy", PO_CreatedBy));
                cmd.Parameters.Add(new SqlParameter("@PO_IsDefaultShipmentAddress", PO_IsDefaultShipmentAddress));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Name", PO_SA_Name));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_CompanyName", PO_SA_CompanyName));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Address", PO_SA_Address));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_City", PO_SA_City));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_PostCode", PO_SA_PostCode));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Region", PO_SA_Region));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Country", PO_SA_Country));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_SpecialInstructions", PO_SA_SpecialInstructions));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Phone", PO_SA_Phone));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Mobile", PO_SA_Mobile));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Email", PO_SA_Email));



                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);


            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }




        /////////////////////////////////////////////////////////////////////// Delete PO Items  By PO_ID /////////////////////////////
        public DataTable deletePOItemsByPOID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_DelPOItems", con);
                cmd.Parameters.Add(new SqlParameter("@PO_ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }

        /////////////////////////////////////////////////////////////////////// Delete PO Payment  By PO_ID /////////////////////////////
        public DataTable deletePOIPaymentsByPOID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_DelPOPayments", con);
                cmd.Parameters.Add(new SqlParameter("@PO_ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable deleteSOIPaymentsByPOID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_DelSOPayments", con);
                cmd.Parameters.Add(new SqlParameter("@SO_ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }




        public DataTable DeletePOrderByPOID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_DelPurchaseOrder", con);
                cmd.Parameters.Add(new SqlParameter("@PO_ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable DeleteSaleOrderByID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_DelSalesOrder", con);
                cmd.Parameters.Add(new SqlParameter("@ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }





        ////////////////////////////////////// Update Purchase Order Item ///////////////////////////////////////////////////////////////////

        //public void POItems(int ItemID, string UPC,string partNumber,string VendorPart,string Description,float frieght,float price,float qty,float qtyReceived,float Cost)
        public void UpdatePOItems(DataTable POItems, int PO_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                //cmd = new SqlCommand("SP_UpdatePOItems", connection);

                cmd = new SqlCommand("SP_AddPOItems", connection);



                cmd.Parameters.Add(new SqlParameter("@PO", POItems));
                cmd.Parameters.Add(new SqlParameter("@PO_ID", PO_ID));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }


        public void UPOItemsonPorFReceivedItems(int POI_ID, int POI_ItemID, string POI_UPC, string POI_PartNo, string POI_VendorPart, string PO_Description, float POI_Frieght, float POI_price, float POI_Qty, float POI_QtyReceived, float POI_Cost, int PO_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                //cmd = new SqlCommand("SP_UpdatePOItems", connection);

                cmd = new SqlCommand("SP_AddPOItemsOnReceivedItems", connection);

                cmd.Parameters.Add(new SqlParameter("@POI_ID", POI_ID));
                cmd.Parameters.Add(new SqlParameter("@POI_ItemID", POI_ItemID));

                cmd.Parameters.Add(new SqlParameter("@POI_UPC", POI_UPC));
                cmd.Parameters.Add(new SqlParameter("@POI_PartNo", POI_PartNo));
                cmd.Parameters.Add(new SqlParameter("@POI_VendorPart", POI_VendorPart));

                cmd.Parameters.Add(new SqlParameter("@PO_Description", PO_Description));
                cmd.Parameters.Add(new SqlParameter("@POI_Frieght", POI_Frieght));
                cmd.Parameters.Add(new SqlParameter("@POI_price", POI_price));
                cmd.Parameters.Add(new SqlParameter("@POI_Qty", POI_Qty));
                cmd.Parameters.Add(new SqlParameter("@POI_QtyReceived", POI_QtyReceived));
                cmd.Parameters.Add(new SqlParameter("@POI_Cost", POI_Cost));
                cmd.Parameters.Add(new SqlParameter("@PO_ID", PO_ID));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }








        /////////////////////////////////////////////////////////////////////// Get Product By UPC/////////////////////////////
        public DataTable getProductByUPC(string upc, int stype)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetProductByUPC", con);
                cmd.Parameters.Add(new SqlParameter("@UPC", upc));
                cmd.Parameters.Add(new SqlParameter("@stype", stype));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }



        /////////////////////////////////////////////////////////////////////// Get Warehouse List/////////////////////////////
        public DataTable FetchWarehouse(int sellerID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetWarehouse", con);
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", sellerID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable GetProductImagesidID(int ID, int Seller_ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetAutionsImagebyProductID", con);
                cmd.Parameters.Add(new SqlParameter("@ProductID", ID));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }



        public DataTable getAutionByID(int ID, int SellerID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("Sp_GetAutionDetailbyID", con);
                cmd.Parameters.Add(new SqlParameter("@TM_ID", ID));
                cmd.Parameters.Add(new SqlParameter("@SellerID", SellerID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }



        public DataTable GetShipTemplateNamebyID(int ID, int SellerID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("Sp_GetShipTemplateNamebyID", con);
                cmd.Parameters.Add(new SqlParameter("@ID", ID));
                cmd.Parameters.Add(new SqlParameter("@SellerID", SellerID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }

        public DataTable GetShipTemplateData(int ID, int SellerID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("Sp_GetShipTemplateDatabyID", con);
                cmd.Parameters.Add(new SqlParameter("@ID", ID));
                cmd.Parameters.Add(new SqlParameter("@SellerID", SellerID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }




        /////////////////////////////////////////////////////////////////////// Get Product By id/////////////////////////////
        public DataTable getProductByID(int ID, int SellerID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetProductByID", con);
                cmd.Parameters.Add(new SqlParameter("@P_ID", ID));
                cmd.Parameters.Add(new SqlParameter("@SellerID", SellerID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable getProductByID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetProductByID", con);
                cmd.Parameters.Add(new SqlParameter("@P_ID", ID));
                //  cmd.Parameters.Add(new SqlParameter("@SellerID", SellerID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }






        public DataTable GetChannelNamebyID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetChannelNameByID", con);
                cmd.Parameters.Add(new SqlParameter("@Channel_ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable GetFeatureImagebyItemID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetFeatureImagebyItemID", con);
                cmd.Parameters.Add(new SqlParameter("@ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }







        /////////////////////////////////////////////////////////////////////// Get Vendor By id/////////////////////////////
        public DataTable getVendorByID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetVendorByID", con);
                cmd.Parameters.Add(new SqlParameter("@V_ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }



        public DataTable getCustomerByID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetCustomerByID", con);
                cmd.Parameters.Add(new SqlParameter("@ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }



        /////////////////////////////////////////////////////////////////////// Get Product By UPC/////////////////////////////

        /////////////////////////////////////////////////////////////////////// Get Warehouse By id/////////////////////////////
        public DataTable getWarehouseByID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetWarehouseByID", con);
                cmd.Parameters.Add(new SqlParameter("@Wh_ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }

        /////////////////////////////////////////////////////////////////////// Delete Product By ID /////////////////////////////
        public DataTable deleteProductByID(string ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_deleteGenProduct", con);
                cmd.Parameters.Add(new SqlParameter("@P_ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable deleteAutionByID(string ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_deleteAutionbyID", con);
                cmd.Parameters.Add(new SqlParameter("@ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }



        /////////////////////////////////////////////////////////////////////// Delete Vendor By ID /////////////////////////////
        public DataTable deleteVendorByID(string ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_deleteVendor", con);
                cmd.Parameters.Add(new SqlParameter("@V_ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable deleteCustomerByID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_deleteCustomer", con);
                cmd.Parameters.Add(new SqlParameter("@ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }



        public DataTable deleteProductImageByID(int ID, int SellerID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_deleteProductImagebyID", con);
                cmd.Parameters.Add(new SqlParameter("@ID", ID));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", SellerID));



                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        /////////////////////////////////////////////////////////////////////// Delete Warehouse By ID /////////////////////////////
        public DataTable deleteWarehouseByID(string ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_deleteWarehouse", con);
                cmd.Parameters.Add(new SqlParameter("@Wh_ID", ID));


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }

        ////////////////////////////////////// Add Purchase Order ///////////////////////////////////////////////////////////////////

        public int AddPurchaseOrder(string PO_Title, int V_ID, string V_Name, int PO_IscashPurchase, string PO_Type, string PO_Date, string PO_DueDate, string PO_ReceivedDate, string PO_Note, string PO_InvoiceNo, string PO_Status,

                                     string PO_PaidStatus, string PO_StatusDate, string PO_Assignto, string PO_TrackingID, float PO_TotalAmount, float PO_Discount, float PO_TaxAmount, float PO_TaxType, float PO_TaxinPercentage, int PO_IsImportedAmount,
                                     float PO_ImportedLocalAmount, float PO_ImportedFreightAmount, string PO_SpecialInstructions, string PO_PrintingInstructions, string PO_CreatedBy, int PO_IsDefaultShipmentAddress, string PO_SA_Name, string PO_SA_CompanyName,
                                     string PO_SA_Address, string PO_SA_City, string PO_SA_PostCode, string PO_SA_Region, string PO_SA_Country, string PO_SA_SpecialInstructions, string PO_SA_Phone, string PO_SA_Mobile, string PO_SA_Email, string PO_Curency)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_AddNewPO", connection);

                cmd.Parameters.Add(new SqlParameter("@PO_Title", PO_Title));
                cmd.Parameters.Add(new SqlParameter("@V_ID", V_ID));
                cmd.Parameters.Add(new SqlParameter("@V_Name", V_Name));
                cmd.Parameters.Add(new SqlParameter("@PO_IsCashPurchase", PO_IscashPurchase));
                cmd.Parameters.Add(new SqlParameter("@PO_Type", PO_Type));
                cmd.Parameters.Add(new SqlParameter("@PO_Date", PO_Date));
                cmd.Parameters.Add(new SqlParameter("@PO_DueDate", PO_DueDate));
                cmd.Parameters.Add(new SqlParameter("@PO_ReceivedDate", PO_ReceivedDate));
                cmd.Parameters.Add(new SqlParameter("@PO_Note", PO_Note));
                cmd.Parameters.Add(new SqlParameter("@PO_InvoiceNo", PO_InvoiceNo));
                cmd.Parameters.Add(new SqlParameter("@PO_Status", PO_Status));
                cmd.Parameters.Add(new SqlParameter("@PO_PaidStatus", PO_PaidStatus));
                cmd.Parameters.Add(new SqlParameter("@PO_StatusDate", PO_StatusDate));
                cmd.Parameters.Add(new SqlParameter("@PO_Assignto", PO_Assignto));
                cmd.Parameters.Add(new SqlParameter("@PO_TrackingID", PO_TrackingID));
                cmd.Parameters.Add(new SqlParameter("@PO_TotalAmount", PO_TotalAmount));
                cmd.Parameters.Add(new SqlParameter("@PO_Discount", PO_Discount));
                cmd.Parameters.Add(new SqlParameter("@PO_TaxAmount", PO_TaxAmount));
                cmd.Parameters.Add(new SqlParameter("@PO_TaxType", PO_TaxType));
                cmd.Parameters.Add(new SqlParameter("@PO_TaxinPercentage", PO_TaxinPercentage));
                cmd.Parameters.Add(new SqlParameter("@PO_IsImportedAmount", PO_IsImportedAmount));
                cmd.Parameters.Add(new SqlParameter("@PO_ImportedLocalAmount", PO_ImportedLocalAmount));
                cmd.Parameters.Add(new SqlParameter("@PO_ImportedFreightAmount", PO_ImportedFreightAmount));
                cmd.Parameters.Add(new SqlParameter("@PO_SpecialInstructions", PO_SpecialInstructions));
                cmd.Parameters.Add(new SqlParameter("@PO_PrintingInstructions", PO_PrintingInstructions));
                cmd.Parameters.Add(new SqlParameter("@PO_CreatedBy", PO_CreatedBy));
                cmd.Parameters.Add(new SqlParameter("@PO_IsDefaultShipmentAddress", PO_IsDefaultShipmentAddress));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Name", PO_SA_Name));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_CompanyName", PO_SA_CompanyName));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Address", PO_SA_Address));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_City", PO_SA_City));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_PostCode", PO_SA_PostCode));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Region", PO_SA_Region));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Country", PO_SA_Country));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_SpecialInstructions", PO_SA_SpecialInstructions));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Phone", PO_SA_Phone));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Mobile", PO_SA_Mobile));
                cmd.Parameters.Add(new SqlParameter("@PO_SA_Email", PO_SA_Email));
                cmd.Parameters.Add(new SqlParameter("@PO_Curency", PO_Curency));

                cmd.Parameters.Add("@return_id", SqlDbType.Int).Direction = ParameterDirection.Output;

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return Convert.ToInt32(cmd.Parameters["@return_id"].Value);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }
            return Convert.ToInt32(cmd.Parameters["@return_id"].Value);
        }




        ////////////////////////////////////// Add Purchase Order Item ///////////////////////////////////////////////////////////////////

        //public void AddPOItems(int ItemID, string UPC,string partNumber,string VendorPart,string Description,float frieght,float price,float qty,float qtyReceived,float Cost)
        public void AddPOItems(DataTable POItems, int POID)

        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_AddPOItems", connection);

                cmd.Parameters.Add(new SqlParameter("@PO", POItems));
                cmd.Parameters.Add(new SqlParameter("@PO_ID", POID));

                //cmd.Parameters.Add(new SqlParameter("@POI_UPC", POItems));
                //cmd.Parameters.Add(new SqlParameter("@POI_PartNo", partNumber));
                //cmd.Parameters.Add(new SqlParameter("@POI_VendorPart", VendorPart));
                //cmd.Parameters.Add(new SqlParameter("@PO_Description", Description));
                //cmd.Parameters.Add(new SqlParameter("@POI_Frieght", frieght));
                //cmd.Parameters.Add(new SqlParameter("@POI_price", price));
                //cmd.Parameters.Add(new SqlParameter("@POI_Qty", qty));
                //cmd.Parameters.Add(new SqlParameter("@POI_QtyReceived", qtyReceived));
                //cmd.Parameters.Add(new SqlParameter("@POI_Cost", Cost));


                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }


        ////////////////////////////////////// Add Purchase Order Payment ///////////////////////////////////////////////////////////////////

        public void AddPOPayment(DataTable PO_Payment, int PO_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_AddPOPayments", connection);



                cmd.Parameters.Add(new SqlParameter("@PO_Payment", PO_Payment));
                cmd.Parameters.Add(new SqlParameter("@PO_ID", PO_ID));


                //cmd.Parameters.Add(new SqlParameter("@POP_Method", Method));
                //cmd.Parameters.Add(new SqlParameter("@POP_PaymentDate", paymentDate));
                //cmd.Parameters.Add(new SqlParameter("@POP_Amount", Amount));
                //cmd.Parameters.Add(new SqlParameter("@POP_PaymentBy", paymentBy));
                //cmd.Parameters.Add(new SqlParameter("@POP_Notes", Notes));


                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }






        //////////////////////////////////===============================================================////////////////////////////

        ///////////////////////////////////////////////======================Bs ======================================//////////////////
        ////////////////////////////////////////// Add update categories ///////////////////////////////////////////////////////////////////

        public int AddUpdateCategories(string Cat_Name, int Cat_ParentCategory, int Cat_FeaturesCategory,
                                                int Cat_Status, int Cat_Isvoid, int Cat_SortingOrder,
                                                string Cat_CategoryImage, int Seller_ID, string Cat_Path)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_AddUpdateCategory", connection);


                cmd.Parameters.Add(new SqlParameter("@Cat_Name", Cat_Name));
                cmd.Parameters.Add(new SqlParameter("@Cat_ParentCategory", Cat_ParentCategory));
                cmd.Parameters.Add(new SqlParameter("@Cat_FeaturesCategory", Cat_FeaturesCategory));
                cmd.Parameters.Add(new SqlParameter("@Cat_Status", Cat_Status));
                cmd.Parameters.Add(new SqlParameter("@Cat_Isvoid", Cat_Isvoid));
                cmd.Parameters.Add(new SqlParameter("@Cat_SortingOrder", Cat_SortingOrder));
                cmd.Parameters.Add(new SqlParameter("@Cat_CategoryImage", Cat_CategoryImage));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));
                cmd.Parameters.Add(new SqlParameter("@Cat_Path", Cat_Path));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);
                return 1;
            }
            catch (Exception ex)
            {
                return 0;
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                //connection.Close();
            }

        }


        public void UpdateCategories(int Cat_ID, string Cat_Name, int Cat_ParentCategory, int Cat_FeaturesCategory,
                                            int Cat_Status, int Cat_SortingOrder,
                                            string Cat_CategoryImage, int Seller_ID, string Cat_Path)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_UpdateCategory", connection);
                cmd.Parameters.Add(new SqlParameter("@Cat_ID", Cat_ID));
                cmd.Parameters.Add(new SqlParameter("@Cat_Name", Cat_Name));
                cmd.Parameters.Add(new SqlParameter("@Cat_ParentCategory", Cat_ParentCategory));
                cmd.Parameters.Add(new SqlParameter("@Cat_FeaturesCategory", Cat_FeaturesCategory));
                cmd.Parameters.Add(new SqlParameter("@Cat_Status", Cat_Status));
                cmd.Parameters.Add(new SqlParameter("@Cat_SortingOrder", Cat_SortingOrder));
                cmd.Parameters.Add(new SqlParameter("@Cat_CategoryImage", Cat_CategoryImage));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));
                cmd.Parameters.Add(new SqlParameter("@Cat_Path", Cat_Path));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                //connection.Close();
            }
        }




        public int AddShippingTemplate(string TemplateName, int Seller_ID, int Channel_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_AddShippingTemplate", connection);
                cmd.Parameters.Add(new SqlParameter("@TemplateName", TemplateName));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));
                cmd.Parameters.Add(new SqlParameter("@Channel_ID", Channel_ID));
                cmd.Parameters.Add("@return_id", SqlDbType.Int).Direction = ParameterDirection.Output;

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);
                return Convert.ToInt32(cmd.Parameters["@return_id"].Value);

            }
            catch (Exception ex)
            {
                return 0;
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }
        }



        public void AddShippingTemplateDetail(int TemplateID, float Cost, string Detail, string Courier, int Seller_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_AddShippingTemplateDetail", connection);
                cmd.Parameters.Add(new SqlParameter("@TemplateID", @TemplateID));
                cmd.Parameters.Add(new SqlParameter("@Cost", Cost));
                cmd.Parameters.Add(new SqlParameter("@Detail", Detail));
                cmd.Parameters.Add(new SqlParameter("@Courier", Courier));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));



                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                //connection.Close();
            }
        }



        public void UpdateShippingTemplateName(int TemplateID, string TemplateName, int Seller_ID, int Channel_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_UpdateShippingTemplateName", connection);

                cmd.Parameters.Add(new SqlParameter("@ID", TemplateID));
                cmd.Parameters.Add(new SqlParameter("@TemplateName", TemplateName));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));
                cmd.Parameters.Add(new SqlParameter("@Channel_ID", Channel_ID));


                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                //connection.Close();
            }
        }

        public void DeleteOLShipTemplatebyID(int TemplateID, int Seller_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_DeleteShipmentTemplatebyID", connection);

                cmd.Parameters.Add(new SqlParameter("@ID", TemplateID));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));


                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                //connection.Close();
            }
        }

        public void DeleteCategory(int Cat_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_GetDeleteCategory", connection);
                cmd.Parameters.Add(new SqlParameter("@Cat_ID", Cat_ID));


                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                //connection.Close();
            }
        }

        public DataTable BindAllCategoriesBySellerID(int Seller_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_BindAllCategoriesBySellerID", connection);

                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();

                //connection.Close();
            }
            return dt;
        }

        public DataTable BindChannelListBySellerID(int Seller_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_GetChannelListbySeller", connection);

                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();

                //connection.Close();
            }
            return dt;
        }

        public DataTable BindBrandListBySellerID(int Seller_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_GetBrandListbySeller", connection);

                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();

                //connection.Close();
            }
            return dt;
        }


        public DataTable StaffListBySellerID(int Seller_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_GetStaffListbySeller", connection);

                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();

                //connection.Close();
            }
            return dt;
        }





        public DataTable GetCategoryDetailbyID(int Id, int sellerid)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetCategoryDetailbyID", con);
                cmd.Parameters.Add(new SqlParameter("@Id", Id));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", sellerid));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }

        //////////////////////////////////////////  Purchase Order ///////////////////////////////////////////////////////////////////

        public DataTable BindPurchaseOrderByVendorID(int V_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_BindAllPurchaseOrderByVendorID", connection);

                cmd.Parameters.Add(new SqlParameter("@V_ID", V_ID));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();

                //connection.Close();
            }
            return dt;
        }



        //////////////////////////////////////////  Sales Order ///////////////////////////////////////////////////////////////////

        public DataTable BindSalesOrderBySellerID(int Seller_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_BindSalesOrderBySellerID", connection);

                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();

                //connection.Close();
            }
            return dt;
        }



        public DataTable BindRptMonthlySalebyProducts(int Seller_ID, int year, int type)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_BindProductSalesBySellerID", connection);

                cmd.Parameters.Add(new SqlParameter("@sid", Seller_ID));
                cmd.Parameters.Add(new SqlParameter("@year", year));
                cmd.Parameters.Add(new SqlParameter("@type", type));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();

                //connection.Close();
            }
            return dt;
        }



        public DataTable BindProductsSaleBySellerID(int Seller_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_BindProductSalesBySellerID", connection);

                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();

                //connection.Close();
            }
            return dt;
        }










        //////////////////////////////////BS end===============================================================///////////////////////////

        public DataTable GetSellerInfo(string UserID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetSellerIDbyUser", connection);
                cmd.Parameters.Add(new SqlParameter("@UserID", UserID));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                return dt;
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }

        public DataTable GetChannelInfobySellerIDSellerInfo(string username)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetDefaultChannelInfobySeller", connection);
                cmd.Parameters.Add(new SqlParameter("@username", username));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                return dt;
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }

        public DataTable RetrieveUserlist(string SellerID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetUserslist", connection);
                cmd.Parameters.Add(new SqlParameter("@SellerID", SellerID));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }
            return dt;
        }

        public DataTable GetEmailTypebyID(int emailTypeID, int SellerID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetEmailTypebyID", connection);

                cmd.Parameters.Add(new SqlParameter("@emailTypeID", emailTypeID));
                cmd.Parameters.Add(new SqlParameter("@SellerID", SellerID));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }
            return dt;
        }



        public int GetUserValidityTimeKeepingUser(string UserName)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_CheckUserNameTimeKeepingUsers", con);
                cmd.Parameters.Add(new SqlParameter("@UserName", UserName));


                cmd.Parameters.Add("@status", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return Convert.ToInt32(cmd.Parameters["@status"].Value);
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return 0;
        }

        public DataTable CountCompExistingUsers(int CompID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SA_CountCompExistingUsers", con);
                cmd.Parameters.Add(new SqlParameter("@CompID", CompID));

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public void AddUserProfile(string user, string fname, string lname, string position, DateTime updatetime, int SellerID, int ChannelID, int Active, string UserRole, string email)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_InsertStaff_profile", con);
                cmd.Parameters.Add(new SqlParameter("@UserName", user));
                cmd.Parameters.Add(new SqlParameter("@First_Name", fname));
                cmd.Parameters.Add(new SqlParameter("@Last_Name", lname));
                cmd.Parameters.Add(new SqlParameter("@Position", position));
                cmd.Parameters.Add(new SqlParameter("@updatetime", updatetime));
                cmd.Parameters.Add(new SqlParameter("@SellerID", SellerID));
                cmd.Parameters.Add(new SqlParameter("@ChannelID", ChannelID));
                cmd.Parameters.Add(new SqlParameter("@Active", Active));
                cmd.Parameters.Add(new SqlParameter("@UserRole", UserRole));
                cmd.Parameters.Add(new SqlParameter("@email", email));

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }

        }

        public void UpdateUserProfile(string user, string fname, string lname, string position, DateTime updatetime, int SellerID, int ChannelID, int Active, string UserRole, string email)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_UpdateStaff_profile", con);
                cmd.Parameters.Add(new SqlParameter("@UserName", user));
                cmd.Parameters.Add(new SqlParameter("@First_Name", fname));
                cmd.Parameters.Add(new SqlParameter("@Last_Name", lname));
                cmd.Parameters.Add(new SqlParameter("@Position", position));
                cmd.Parameters.Add(new SqlParameter("@updatetime", updatetime));
                cmd.Parameters.Add(new SqlParameter("@SellerID", SellerID));
                cmd.Parameters.Add(new SqlParameter("@ChannelID", ChannelID));
                cmd.Parameters.Add(new SqlParameter("@Active", Active));
                cmd.Parameters.Add(new SqlParameter("@UserRole", UserRole));
                cmd.Parameters.Add(new SqlParameter("@email", email));

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }

        }



        public void AddUserProfile(string user, int SellerID, int ChannelID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_InsertChannelUsersStaff", con);
                cmd.Parameters.Add(new SqlParameter("@UserName", user));
                cmd.Parameters.Add(new SqlParameter("@SellerID", SellerID));
                cmd.Parameters.Add(new SqlParameter("@ChannelID", ChannelID));

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }

        }

        public DataTable RetrieveUserInfo(string user, int SellerID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_GetUserdetail", con);
                cmd.Parameters.Add(new SqlParameter("@username", user));
                cmd.Parameters.Add(new SqlParameter("@SellerID", SellerID));

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public void AddUpdateEmailTemplate(int ID, string TemplateName, string RoleName, string Foruse, int DisplayOrder, string Emailto, string Emailfrom, string emailBCC, string AttachedReport, string Subject, string emailbody, bool Status, int SellerID, int ChannelID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_AddUpdateEmailTemplate", connection);

                cmd.Parameters.Add(new SqlParameter("@ID", ID));
                cmd.Parameters.Add(new SqlParameter("@TemplateName", TemplateName));
                cmd.Parameters.Add(new SqlParameter("@RoleName", RoleName));
                cmd.Parameters.Add(new SqlParameter("@Foruse", Foruse));
                cmd.Parameters.Add(new SqlParameter("@DisplayOrder", DisplayOrder));
                cmd.Parameters.Add(new SqlParameter("@Emailto", Emailto));
                cmd.Parameters.Add(new SqlParameter("@Emailfrom", Emailfrom));
                cmd.Parameters.Add(new SqlParameter("@emailBCC", emailBCC));
                cmd.Parameters.Add(new SqlParameter("@AttachedReport", AttachedReport));
                cmd.Parameters.Add(new SqlParameter("@Subject", Subject));
                cmd.Parameters.Add(new SqlParameter("@emailbody", emailbody));
                cmd.Parameters.Add(new SqlParameter("@Status", Status));
                cmd.Parameters.Add(new SqlParameter("@SellerID", SellerID));
                cmd.Parameters.Add(new SqlParameter("@ChannelID", ChannelID));

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }

        public DataTable BindEmailTemplate(int ID, int SellerID, int ChannelID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_BindTemplateID", con);
                cmd.Parameters.Add(new SqlParameter("@ID", ID));
                cmd.Parameters.Add(new SqlParameter("@SellerID", SellerID));
                cmd.Parameters.Add(new SqlParameter("@ChannelID", ChannelID));

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable EmailTypeList(int Seller_ID, int ChannelID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                //cmd = new SqlCommand("SP_GetEmailTemplateList", connection);
                cmd = new SqlCommand("SP_GetInvoiceTemplatelist", connection);

                cmd.Parameters.Add(new SqlParameter("@SellerID", Seller_ID));
                // cmd.Parameters.Add(new SqlParameter("@ChannelID", ChannelID));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();

                //connection.Close();
            }
            return dt;
        }

        public void DeleteStaffbyID(string username, int Seller_ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_DeleteStaffbyID", connection);

                cmd.Parameters.Add(new SqlParameter("@username", username));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                //connection.Close();
            }
        }





        /// ******************Getting Total Orders************************************

        public int GetingTotalorders(int type)
        {

            int rec_value = 0;


            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_GetingTotalOrders", connection);
                cmd.Parameters.Add(new SqlParameter("@Sales_Type", type));
                cmd.Parameters.Add("@orderpayment", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                rec_value = Convert.ToInt32(cmd.Parameters["@orderpayment"].Value);

                return rec_value;

            }
            catch (Exception ex)
            {

                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                //connection.Close();
            }



            return rec_value;
        }
        /////////////////////////////////////*************Tomarrow Orders******************///////////////////////////////////












        /// ******************Getting Total Sales ************************************

        public int GetingTotalSales(int type)
        {


            int rec_value = 0;


            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_GetingTotalSales", connection);
                cmd.Parameters.Add(new SqlParameter("@Sales_Type", type));
                cmd.Parameters.Add("@orderpayment", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                rec_value = Convert.ToInt32(cmd.Parameters["@orderpayment"].Value);

                return rec_value;

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                //connection.Close();
            }



            return rec_value;
        }

        //***********************************Products Quality With Categories Fetching*********************

        public int GettingQuantityCheck(int type)
        {


            int rec_value = 0;


            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_Products_Quantity_Categories", connection);
                cmd.Parameters.Add(new SqlParameter("@category", type));
                cmd.Parameters.Add("@quantity", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                rec_value = Convert.ToInt32(cmd.Parameters["@quantity"].Value);

                return rec_value;

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                //connection.Close();
            }



            return rec_value;
        }


        //***********************************Order  Quality With Categories Fetching*********************

        public int GettingOrdersCOnditons(int type)
        {


            int rec_value = 0;


            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_Getting_Diff_Conditons_in_orders", connection);
                cmd.Parameters.Add(new SqlParameter("@category", type));
                cmd.Parameters.Add("@orders", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                rec_value = Convert.ToInt32(cmd.Parameters["@orders"].Value);

                return rec_value;

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                //connection.Close();
            }


            return rec_value;
        }

        //***********************************************************************fetching_vendors********************************************8

        public DataTable fetching_vendors()
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_fetching_vendors_for_search", con);

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        //***********************************************************************fetching_Warehouse********************************************8

        public DataTable fetching_Warehouse()
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_fetching_Warehouse_for_searching", con);

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }

        //***********************************************************************fetching_advance search datatable********************************************8

        public DataTable fetching_advance_search_result(string find, string where, string start_with, string greater, string lesser, string min, string wharehouse, string vendor, string seller_id, string channel)
        {

            SqlConnection con = new SqlConnection(connectionStr);
            SqlCommand cmd = new SqlCommand();
            DataTable dt = new DataTable();
            con.Open();
            string query = "";
            string qstatus = "";
            string qwhere = "";
            string qquantity = "";
            string quantityles = "";
            string qprice = "";
            string qvendor = "";
            string qwarehouse = "";
            string comquerry = "";

            try
            {

                if (channel.Length == 0)
                {
                    query = "select top 5  P_ID, P_Title,P_ShortDescription,P_PartNumber,P_BrandName,P_Condition,P_Cost,P_Quantity,P_Category,P_SalePrice,P_StockAvailability,P_Status,P_ReorderStockLevel,Channel_ID, P_FeatureImage from   tb_Products where Seller_ID =" + seller_id + " ";

                    if (find.Length != 0)
                    {
                        qstatus = " and " + find + " ";
                    }

                    if (where.Length != 0 && start_with.Length != 0)
                    {


                        qwhere = " and " + where + "  like    '" + start_with + "%" + "'  ";

                    }
                    if (greater.Length != 0)
                    {
                        qquantity = "  and P_Quantity  >  " + greater;
                    }

                    if (lesser.Length != 0)
                    {
                        quantityles = " and P_Quantity  < " + lesser + " ";
                    }
                    if (min.Length != 0)
                    {
                        qprice = " and P_Cost > " + min + " ";
                    }
                    if (vendor.Length != 0)
                    {
                        qvendor = " and P_VendorName = '" + vendor + "' ";
                    }

                    if (wharehouse.Length != 0)
                    {
                        qwarehouse = " and P_WareHouselocationID = '" + wharehouse + "' ";
                    }

                    comquerry = query + qstatus + qwhere + qquantity + quantityles + qprice + qvendor + qwarehouse;
                }
                ///////////////////////////////////////////////////Tradem///////////////////////////////////////////////////////////////***********************************
                else if (channel == "Trademe")
                {

                    query = "select    distinct prodt.P_ID, prodt.P_Title,prodt.P_ShortDescription,prodt.P_PartNumber,prodt.P_BrandName,prodt.P_Condition,prodt.P_Cost,prodt.P_Quantity,prodt.P_Category,prodt.P_SalePrice,prodt.P_StockAvailability,prodt.P_Status,prodt.P_ReorderStockLevel,prodt.Channel_ID, prodt.P_FeatureImage from   tb_Products as prodt INNER JOIN tb_TradeMe as td ON td.P_ID = prodt.P_ID and td.TM_ListingID != '0'  where prodt.Seller_ID =" + seller_id + " ";

                    if (find.Length != 0)
                    {
                        qstatus = " and " + find + " ";
                    }

                    if (where.Length != 0 && start_with.Length != 0)
                    {


                        qwhere = " and prodt." + where + "  like    '" + start_with + "%" + "'  ";

                    }
                    if (greater.Length != 0)
                    {
                        qquantity = "  and prodt.P_Quantity  >  " + greater;
                    }

                    if (lesser.Length != 0)
                    {
                        quantityles = " and prodt.P_Quantity  < " + lesser + " ";
                    }
                    if (min.Length != 0)
                    {
                        qprice = " and prodt.P_Cost > " + min + " ";
                    }
                    if (vendor.Length != 0)
                    {
                        qvendor = " and prodt.P_VendorName = '" + vendor + "' ";
                    }

                    if (wharehouse.Length != 0)
                    {
                        qwarehouse = " and prodt.P_WareHouselocationID = '" + wharehouse + "' ";
                    }

                    comquerry = query + qstatus + qwhere + qquantity + quantityles + qprice + qvendor + qwarehouse;

                }


                cmd = new SqlCommand(comquerry, con);


                SqlDataReader sdr = cmd.ExecuteReader();

                dt = new DataTable();
                dt.Load(sdr);
                return dt;

            }

            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }

        //***********************************************************************fetching_Warehouse********************************************8

        public DataTable fetching_sellers()
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_fetching_sellers_for_search", con);
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable fetching_advance_seach_result_of_orders(string find, string where, string start_with, string date_from, string date_to, string min_price, string max_price, string assigned_to, string invoice_type, string status, string from_days_ago, string warehouse, string channel, int seller_id)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            SqlCommand cmd = new SqlCommand();
            DataTable dt = new DataTable();
            con.Open();
            string query = "";
            string qstatus = "";
            string qwhere = "";
            string qquantity = "";
            string quantityles = "";
            string qprice = "";
            string assign_to = "";
            string qmaxprice = "";
            string qwarehouse = "";
            string comquerry = "";
            string st_invoice_type = "";
            string st_from_days_ago = "";
            string st_channel = "";




            try
            {

                query = "select * from tb_Orders where  Seller_ID ='" + seller_id + "'   ";

                if (find.Length != 0)
                {
                    qstatus = " and " + find + " ";
                }

                if (where.Length != 0 && start_with.Length != 0)
                {


                    qwhere = " and " + where + "  like    '" + start_with + "%" + "'  ";

                }
                if (date_from.Length != 0)
                {
                    qquantity = "  and  OrderDate >= Convert(datetime, '" + date_from + "' )  ";
                }

                if (date_to.Length != 0)
                {
                    quantityles = " and OrderDate <= Convert(datetime, '" + date_to + "')  ";
                }
                if (min_price.Length != 0)
                {
                    qprice = " and TotalAmount > " + min_price + " ";
                }
                if (max_price.Length != 0)
                {
                    qmaxprice = " and TotalAmount <  " + max_price + " ";
                }
                if (assigned_to.Length != 0)
                {
                    assign_to = " and AssignedTo = '" + assigned_to + "' ";
                }
                if (status.Length != 0)
                {
                    qstatus = " and " + status + " ";
                }
                if (invoice_type.Length != 0)
                {
                    st_invoice_type = " and  " + invoice_type + " ";
                }

                if (from_days_ago.Length != 0)
                {
                    st_from_days_ago = " and  DATEDIFF(DAY," + from_days_ago + ", GETDATE()) =OrderDate";
                }
                if (channel.Length != 0)
                {
                    st_channel = " and Channel_ID = '" + channel + "' ";
                }






                comquerry = query + qstatus + qwhere + qquantity + quantityles + qprice + qmaxprice + qwarehouse + st_from_days_ago + st_invoice_type + assign_to + st_channel;

                cmd = new SqlCommand(comquerry, con);


                SqlDataReader sdr = cmd.ExecuteReader();

                dt = new DataTable();
                dt.Load(sdr);
                return dt;

            }

            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;

        }



        //*******************************************Fetching Channel****************************************************

        public DataTable fetching_channels()
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_fetching_channellist_for_searching", con);
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }

        public DataTable fetching_advance_search_result_of_vendor(string find, string where, string start_with, string seller_id)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            SqlCommand cmd = new SqlCommand();
            DataTable dt = new DataTable();
            con.Open();
            string query = "";
            string qstatus = "";
            string qwhere = "";

            string comquerry = "";

            try
            {

                query = "select  V_ID,V_Name,V_CompanyName,V_City,V_PostCode,V_PhoneNo,V_MobileNo,V_Email FROM tb_Vendors where Seller_ID =" + seller_id + " ";

                if (find.Length != 0)
                {
                    qstatus = " and " + find + " ";
                }

                if (where.Length != 0 && start_with.Length != 0)
                {


                    qwhere = " and " + where + "  like    '" + start_with + "%" + "'  ";

                }








                comquerry = query + qstatus + qwhere;

                cmd = new SqlCommand(comquerry, con);


                SqlDataReader sdr = cmd.ExecuteReader();

                dt = new DataTable();
                dt.Load(sdr);
                return dt;

            }

            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable fetching_advance_seach_result_of_Purchase_Orders(string find, string where, string start_with, string date_from, string date_to, string min_price, string max_price, string status, int seller_id)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            SqlCommand cmd = new SqlCommand();
            DataTable dt = new DataTable();
            con.Open();
            string query = "";
            string qstatus = "";
            string qwhere = "";
            string qquantity = "";
            string quantityles = "";
            string qprice = "";
            string qmaxprice = "";

            string comquerry = "";





            try
            {

                query = "select * from tbl_PurchaseOrder where Seller_ID ='" + seller_id + "' ";

                if (find.Length != 0)
                {
                    qstatus = " and " + find + " ";
                }

                if (where.Length != 0 && start_with.Length != 0)
                {


                    qwhere = " and " + where + "  like    '" + start_with + "%" + "'  ";

                }
                if (date_from.Length != 0)
                {
                    qquantity = "  and  PO_Date >= Convert(datetime, '" + date_from + "' )  ";
                }

                if (date_to.Length != 0)
                {
                    quantityles = " and PO_Date <= Convert(datetime, '" + date_to + "')  ";
                }
                if (min_price.Length != 0)
                {
                    qprice = " and PO_TotalAmount > " + min_price + " ";
                }
                if (max_price.Length != 0)
                {
                    qmaxprice = " and PO_TotalAmount <  " + max_price + " ";
                }

                if (status.Length != 0)
                {
                    qstatus = " and " + status + " ";
                }


                comquerry = query + qstatus + qwhere + qquantity + quantityles + qprice + qmaxprice;

                cmd = new SqlCommand(comquerry, con);


                SqlDataReader sdr = cmd.ExecuteReader();

                dt = new DataTable();
                dt.Load(sdr);
                return dt;

            }

            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable fetching_advance_seach_result_of_Customer_list(string find, string where, string start_with, string date_from, string date_to, int seller_id)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            SqlCommand cmd = new SqlCommand();
            DataTable dt = new DataTable();
            con.Open();
            string query = "";
            string qstatus = "";
            string qwhere = "";
            string qquantity = "";
            string quantityles = "";


            string comquerry = "";





            try
            {

                query = "select  * FROM    tb_Customers WHERE   Seller_ID ='" + seller_id + "' ";

                if (find.Length != 0)
                {
                    qstatus = " and " + find + " ";
                }

                if (where.Length != 0 && start_with.Length != 0)
                {


                    qwhere = " and " + where + "  like    '" + start_with + "%" + "'  ";

                }
                if (date_from.Length != 0)
                {
                    qquantity = "  and  PO_Date >= Convert(datetime, '" + date_from + "' )  ";
                }

                if (date_to.Length != 0)
                {
                    quantityles = " and PO_Date <= Convert(datetime, '" + date_to + "')  ";
                }



                comquerry = query + qstatus + qwhere + qquantity + quantityles;

                cmd = new SqlCommand(comquerry, con);


                SqlDataReader sdr = cmd.ExecuteReader();

                dt = new DataTable();
                dt.Load(sdr);
                return dt;

            }

            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable Fetching_Data_for_profile(int seller_id)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_fetching_Profile_data", con);
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", seller_id));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;

        }

        public void Updating_Profile_of_user(int seller_id, string business, string detail, string phone, string fax, string email, string city, string address, string country)
        {


            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_Updating_Profile_Data", connection);

                cmd.Parameters.Add(new SqlParameter("@ID", seller_id));
                cmd.Parameters.Add(new SqlParameter("@business", business));
                cmd.Parameters.Add(new SqlParameter("@detail", detail));
                cmd.Parameters.Add(new SqlParameter("@phone", phone));
                cmd.Parameters.Add(new SqlParameter("@fax", fax));
                cmd.Parameters.Add(new SqlParameter("@email", email));
                cmd.Parameters.Add(new SqlParameter("@city", city));
                cmd.Parameters.Add(new SqlParameter("@address", address));
                cmd.Parameters.Add(new SqlParameter("@country", country));

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;

                da.Fill(dt);

            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }

        public DataTable fetching_countries()
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_fetching_countries", con);

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }
        public DataTable fetching_sellers_list()
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_fetching_sellers_list", con);
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public DataTable Fetching_seller_record_by_id(int id)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_fetching_sellers_record_by_id", con);
                cmd.Parameters.Add(new SqlParameter("@ID", id));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;


        }

        public void AddUpdatingSeller(int id, string seller_name, string seller_detail, string seller_phone, string seller_fax, string seller_email, string seller_city, string seller_address, string seller_country, string seller_currency, string seller_type, string seller_remarks, string expire_date, string channellisence, string userlisence, string latitude, string longitude, int tradem, int shopify, int ebay, int amazon, int publish, int default_channel, string channel_name, string channel_description, string consumer_key, string oauth_token, string sig_key_one, string sig_key_two, string SellertimeZoneID, DateTime currentdate)
        {

            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_AddUpdating_Seller_Info", con);
                cmd.Parameters.Add(new SqlParameter("@ID", id));
                cmd.Parameters.Add(new SqlParameter("@sel_name", seller_name));
                cmd.Parameters.Add(new SqlParameter("@sel_detail", seller_detail));
                cmd.Parameters.Add(new SqlParameter("@sel_phone", seller_phone));
                cmd.Parameters.Add(new SqlParameter("@sel_fax", seller_fax));
                cmd.Parameters.Add(new SqlParameter("@sel_email", seller_email));
                cmd.Parameters.Add(new SqlParameter("@sel_city", seller_city));
                cmd.Parameters.Add(new SqlParameter("@sel_address", seller_address));
                cmd.Parameters.Add(new SqlParameter("@sel_country", seller_country));
                cmd.Parameters.Add(new SqlParameter("@currency", seller_currency));
                cmd.Parameters.Add(new SqlParameter("@sel_type", seller_type));
                cmd.Parameters.Add(new SqlParameter("@remarks", seller_remarks));
                cmd.Parameters.Add(new SqlParameter("@expiredate", expire_date));
                cmd.Parameters.Add(new SqlParameter("@channellisence", channellisence));
                cmd.Parameters.Add(new SqlParameter("@userlisence", userlisence));
                cmd.Parameters.Add(new SqlParameter("@latitude", latitude));
                cmd.Parameters.Add(new SqlParameter("@longitue", longitude));
                cmd.Parameters.Add(new SqlParameter("@trademe", tradem));
                cmd.Parameters.Add(new SqlParameter("@shopify", shopify));
                cmd.Parameters.Add(new SqlParameter("@ebay", ebay));
                cmd.Parameters.Add(new SqlParameter("@amazon", amazon));
                cmd.Parameters.Add(new SqlParameter("@publish", publish));
                cmd.Parameters.Add(new SqlParameter("@default", default_channel));
                cmd.Parameters.Add(new SqlParameter("@chnl_name", channel_name));
                cmd.Parameters.Add(new SqlParameter("@chnl_description", channel_description));
                cmd.Parameters.Add(new SqlParameter("@consumer_key", consumer_key));
                cmd.Parameters.Add(new SqlParameter("@oauth_key", oauth_token));
                cmd.Parameters.Add(new SqlParameter("@sig_one", sig_key_one));
                cmd.Parameters.Add(new SqlParameter("@sig_two", sig_key_two));
                cmd.Parameters.Add(new SqlParameter("@seller_timezone", SellertimeZoneID));
                cmd.Parameters.Add(new SqlParameter("@currentdate", currentdate));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);

            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }


        }

        public DataTable Fetching_weekly_report_of_sales(int id, DateTime currentdate)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_BindProductWeeklySaleBySellerID", con);
                cmd.Parameters.Add(new SqlParameter("@sid", id));
                cmd.Parameters.Add(new SqlParameter("@datetime", currentdate));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }

        public String fetching_timezone(int id)
        {
            string returning_value = "";
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {

                cmd = new SqlCommand("SP_fetchingTImezoneBYID", con);


                cmd.Parameters.Add(new SqlParameter("@id", id));
                cmd.Parameters.Add("@timezone", SqlDbType.NVarChar, 250).Direction = ParameterDirection.Output;

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;

                da.Fill(dt);
                returning_value = Convert.ToString(cmd.Parameters["@timezone"].Value);
                return returning_value;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return returning_value;

        }

        public DataTable Fetching_Daily_report_of_sales(int id, DateTime currentdate)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_BindProductDailySaleBySellerID", con);
                cmd.Parameters.Add(new SqlParameter("@sid", id));
                cmd.Parameters.Add(new SqlParameter("@datetime", currentdate));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }






        public void Creating_Variants_for_specific_Products(int product_id, string variant_name, int variant_image, string variant_price, string com_price, string variant_quantity, string variant_sku, string variant_barcode, DateTime current_date, int position, string weight, string weight_unit, string grams)
        {

            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_Submitting_Variants", con);
                cmd.Parameters.Add(new SqlParameter("@P_ID", product_id));
                cmd.Parameters.Add(new SqlParameter("@V_title", variant_name));
                cmd.Parameters.Add(new SqlParameter("@V_price", variant_price));
                cmd.Parameters.Add(new SqlParameter("@V_Sku", variant_sku));
                cmd.Parameters.Add(new SqlParameter("@position", position));
                cmd.Parameters.Add(new SqlParameter("@compare_price", com_price));
                cmd.Parameters.Add(new SqlParameter("@current_date", current_date));
                cmd.Parameters.Add(new SqlParameter("@barcode", variant_barcode));
                cmd.Parameters.Add(new SqlParameter("@image_id", variant_image));
                cmd.Parameters.Add(new SqlParameter("@grams", grams));
                cmd.Parameters.Add(new SqlParameter("@weight", weight));
                cmd.Parameters.Add(new SqlParameter("@weight_unit", weight_unit));
                cmd.Parameters.Add(new SqlParameter("@quantity", variant_quantity));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();


            }
        }


        public int Creating_shopify_Product(string P_ID, string P_title, string P_description, string P_type, string P_vendor, string P_price, string com_price, string cost_per_item, string P_collection, string P_tags, string P_sku, string P_stock, string P_weight, string p_weight_unit, string P_barcode, string Seller_ID, string Channal_ID, int have_variant, string Product_type_path, DateTime current_datetime)
        {
            int product_id = 0;
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_Submition_Shopify_Product", con);
                cmd.Parameters.Add(new SqlParameter("@P_ID", P_ID));
                cmd.Parameters.Add(new SqlParameter("@P_title", P_title));
                cmd.Parameters.Add(new SqlParameter("@P_description", P_description));
                cmd.Parameters.Add(new SqlParameter("@P_type", P_type));
                cmd.Parameters.Add(new SqlParameter("@P_vendor", P_vendor));
                cmd.Parameters.Add(new SqlParameter("@P_price", P_price));
                cmd.Parameters.Add(new SqlParameter("@P_com_price", com_price));
                cmd.Parameters.Add(new SqlParameter("@P_cost_per_item", cost_per_item));
                cmd.Parameters.Add(new SqlParameter("@P_collection", P_collection));
                cmd.Parameters.Add(new SqlParameter("@P_tags", P_tags));
                cmd.Parameters.Add(new SqlParameter("@P_sku", P_sku));
                cmd.Parameters.Add(new SqlParameter("@P_stock", P_stock));
                cmd.Parameters.Add(new SqlParameter("@P_weight", P_weight));
                cmd.Parameters.Add(new SqlParameter("@P_weight_unit", p_weight_unit));
                cmd.Parameters.Add(new SqlParameter("@seller_ID", Seller_ID));
                cmd.Parameters.Add(new SqlParameter("@Channal_ID", Channal_ID));
                cmd.Parameters.Add(new SqlParameter("@HaveVariant", have_variant));
                cmd.Parameters.Add(new SqlParameter("@P_barcode", P_barcode));
                cmd.Parameters.Add(new SqlParameter("@P_type_path", Product_type_path));
                cmd.Parameters.Add(new SqlParameter("@current_date", current_datetime));
                cmd.Parameters.Add("@Product_id", SqlDbType.Int).Direction = ParameterDirection.Output;
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                product_id = Convert.ToInt32(cmd.Parameters["@Product_id"].Value);


                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return product_id;

            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return product_id;

        }


        public DataTable Fetching_Shopify_Product(int Seller_ID, int ID)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_fetching_product_of_Shopify_for_ID", connection);

                cmd.Parameters.Add(new SqlParameter("@ID", ID));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));

                cmd.CommandType = CommandType.StoredProcedure;

                da.SelectCommand = cmd;

                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //Page.ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('Some error occured!!');", true);
            }
            finally
            {
                cmd.Dispose();

                //connection.Close();
            }
            return dt;
        }


        public DataTable fetching_Product_Categoires(string seller_ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_fetching_Product_Categories_for_Shopify", con);
                cmd.Parameters.Add(new SqlParameter("@seller_ID", seller_ID));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }


        public void Submitting_options(int product_id, string variant, string position, string options)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_Submitting_Options", connection);
                cmd.Parameters.Add(new SqlParameter("@ID", product_id));
                cmd.Parameters.Add(new SqlParameter("@Opt_name", variant));
                cmd.Parameters.Add(new SqlParameter("@Opt_position", position));
                cmd.Parameters.Add(new SqlParameter("@opt_values", options));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }


        public DataTable FetchingProducts_forTradeMe(string Seller_ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            SqlCommand cmd = new SqlCommand();
            DataTable dt = new DataTable();
            con.Open();
            string query = "";


            try
            {




                query = "select    distinct prodt.P_ID, prodt.P_Title,prodt.P_ShortDescription,prodt.P_PartNumber,prodt.P_BrandName,prodt.P_Condition,prodt.P_Cost,prodt.P_Quantity,prodt.P_Category,prodt.P_SalePrice,prodt.P_StockAvailability,prodt.P_Status,prodt.P_ReorderStockLevel,prodt.Channel_ID, prodt.P_FeatureImage from   tb_Products as prodt INNER JOIN tb_TradeMe as td ON td.P_ID = prodt.P_ID and td.TM_ListingID != '0'  where prodt.Seller_ID =" + Seller_ID + " ";




                cmd = new SqlCommand(query, con);


                SqlDataReader sdr = cmd.ExecuteReader();

                dt = new DataTable();
                dt.Load(sdr);
                return dt;

            }

            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }

        public void Storing_Images_for_Shopify(int Product_ID, int P_img_ID, int img_sp_id, int image_position, DateTime current_date, string image_alt, int image_width, int image_height, string imagesrc)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_Inserting_image_of_shopify", connection);
                cmd.Parameters.Add(new SqlParameter("@P_ID", Product_ID));
                cmd.Parameters.Add(new SqlParameter("@Product_img_ID", img_sp_id));
                cmd.Parameters.Add(new SqlParameter("@SP_ID", img_sp_id));
                cmd.Parameters.Add(new SqlParameter("@Position", image_position));
                cmd.Parameters.Add(new SqlParameter("@Current_date", current_date));
                cmd.Parameters.Add(new SqlParameter("@Image_alt", image_alt));
                cmd.Parameters.Add(new SqlParameter("@Image_width", image_width));
                cmd.Parameters.Add(new SqlParameter("@Image_height", image_height));
                cmd.Parameters.Add(new SqlParameter("@Img_src", imagesrc));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);

            }
            catch (Exception ex)
            {
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }

        }

        public DataTable GetProductImagesForShopifyID(int ID, int Seller_ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_ShopifyImagebyProductID", con);
                cmd.Parameters.Add(new SqlParameter("@ProductID", ID));
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", Seller_ID));

                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }

        public DataTable Fetching_options_for_ID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_Fetching_Options_for_ID", con);
                cmd.Parameters.Add(new SqlParameter("@ProductID", ID));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt; ;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;

        }


        public DataTable Fetching_Variants_for_ID(int ID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_Fetching_Variants_for_ID", con);
                cmd.Parameters.Add(new SqlParameter("@ProductID", ID));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;

        }


        public string Publishing_Product(string jsonstring, string username, string password, string url)
        {
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.Credentials = new NetworkCredential(username, password);
            request.KeepAlive = false;
            request.ProtocolVersion = HttpVersion.Version10;
            request.Method = "POST";
            byte[] postBytes = Encoding.UTF8.GetBytes(jsonstring);
            request.ContentType = "application/json; charset=UTF-8";
            request.Accept = "application/json";
            request.ContentLength = postBytes.Length;
            Stream requestStream = request.GetRequestStream();
            requestStream.Write(postBytes, 0, postBytes.Length);
            requestStream.Close(); 
            HttpWebResponse response = null;
            try
            {
                response = (HttpWebResponse)request.GetResponse();
            }
            catch (Exception a)
            {
                Console.WriteLine(a.ToString());
            }
            string inventory_item_id = "";
            Stream dataStream = null;
            StreamReader reader = null;
            string responseFromServer = "";
            if (response != null)
            {
                Console.WriteLine(response.StatusDescription);


                dataStream = response.GetResponseStream();
                reader = new StreamReader(dataStream);
                responseFromServer = reader.ReadToEnd();

                if (responseFromServer.Length > 0)
                {
                    JObject json = JObject.Parse(responseFromServer);
                    string id = json["product"]["id"].ToString();
                    string title = json["product"]["title"].ToString();
                    string body = json["product"]["body_html"].ToString();
                    string vendor = json["product"]["vendor"].ToString();
                    string product_type = json["product"]["product_type"].ToString();
                    JArray variants = new JArray();
                    variants = JArray.Parse(json["product"]["variants"].ToString());
                    foreach (JObject content in variants.Children<JObject>())
                    {
                        inventory_item_id = content["inventory_item_id"].ToString();
                        string option11 = content["option1"].ToString();
                        //   Updating_Inventory_Item(inventory_item_id, "15","true");
                    }
                    variants = JArray.Parse(json["product"]["images"].ToString());
                    foreach (JObject content in variants.Children<JObject>())
                    {
                        //string image = content["image"].ToString();
                        // string option11 = content["option1"].ToString();
                    }
                    return inventory_item_id;
                }
                reader.Close();
                dataStream.Close();
                response.Close();


            }
            return inventory_item_id;
        }




        public DataTable Fetching_Shopify_Credentials(string SellerID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_Fetching_Shopify_Channel_Credentials", con);
                cmd.Parameters.Add(new SqlParameter("@Seller_ID", SellerID));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {
                //return false;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;




        }

        public DataTable Fetching_Trademe_Response(string SellerID, string channelID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_fetching_Response_of_TradeMe", con);
                cmd.Parameters.Add(new SqlParameter("@seller_ID", SellerID));
                cmd.Parameters.Add(new SqlParameter("@channel_ID", channelID));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);
                return dt;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }

        public DataTable fetching_advance_search_of_feedback(string find, string where, string startwith, string todate, string fromdate, string promogroup, string action, string sellerID)
        {
            SqlConnection con = new SqlConnection(connectionStr);
            SqlCommand cmd = new SqlCommand();
            DataTable dt = new DataTable();
            con.Open();
            string query = "";
            string qwhere = "";
            string qfind = "";
            string qtodate = "";
            string qfromdate = "";
            string qpromogroup = "";
            string qaction = "";
            string comquerry = "";

            try
            {


                query = "SELECT * FROM tb_Trademe_Response where Seller_ID =" + sellerID + " ";

                if (find.Length != 0)
                {
                    qfind = " and " + find + " ";
                }

                if (where.Length != 0 && startwith.Length != 0)
                {
                    qwhere = " and " + where + "  like    '" + startwith + "%" + "'  ";
                }
                if (todate.Length != 0)
                {
                    qtodate = "  and date  <=  '" + todate + "'";
                }

                if (fromdate.Length != 0)
                {
                    qfromdate = " and date  >= '" + fromdate + "'";
                }
                if (promogroup.Length != 0)
                {
                    qpromogroup = " and Promo_group > " + promogroup + " ";
                }
                if (action.Length != 0)
                {
                    qaction = " and Action = '" + action + "' ";
                }

                comquerry = query + qfind + qwhere + qtodate + qfromdate + qpromogroup + qaction;


                cmd = new SqlCommand(comquerry, con);


                SqlDataReader sdr = cmd.ExecuteReader();

                dt = new DataTable();
                dt.Load(sdr);
                return dt;

            }

            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return dt;
        }

        public void deleteResponseByID(string responseId)
        {

            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();

            try
            {
                cmd = new SqlCommand("SP_Deleting_Response", connection);
                cmd.Parameters.Add(new SqlParameter("@ID", responseId));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);

            }
            catch (Exception ex)
            {
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }


        }




        public void Inserting_Feedback_Custom(string autionid, string date, string messsage, string sellerid, string channelid, string feedbackuserid)
        {
            SqlConnection connection = new SqlConnection(connectionStr);
            connection.Open();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            DataTable dt = new DataTable();
            try
            {
                cmd = new SqlCommand("SP_Submission_Custom_Feeback", connection);
                cmd.Parameters.Add(new SqlParameter("@autionID", autionid));
                cmd.Parameters.Add(new SqlParameter("@message", messsage));
                cmd.Parameters.Add(new SqlParameter("@date", date));
                cmd.Parameters.Add(new SqlParameter("@userID", feedbackuserid));
                cmd.Parameters.Add(new SqlParameter("@sellerID", sellerid));
                cmd.Parameters.Add(new SqlParameter("@channelID", channelid));
                cmd.CommandType = CommandType.StoredProcedure;
                da.SelectCommand = cmd;
                da.Fill(dt);

            }
            catch (Exception ex)
            {
            }
            finally
            {
                cmd.Dispose();
                connection.Close();
            }
        }



    }
}

